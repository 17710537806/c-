#include "add_person.h"
#include "ui_add_person.h"
#include<iostream>
Add_Person::Add_Person(QWidget *parent) : QWidget(parent), ui(new Ui::Add_Person) {
    ui->setupUi(this);

    //设置图标
    setWindowIcon(QIcon(":/image/School.png"));

    //设置标题
    setWindowTitle("学生成绩管理系统");

    //设置栈控件图片
    QPixmap Image_1(":/image/boy_1.png");
    QPixmap Image_2(":/image/boy_2.png");
    QPixmap Image_3(":/image/girl_1.png");
    QPixmap Image_4(":/image/girl_2.png");
    ui->page_1->set_image(Image_1, Image_2);
    ui->page_2->set_image(Image_3, Image_4);


    //设置下拉内容
    QStringList age;
    for(int i = 8; i <= 25; ++i) {
        age.append(QString::number(i));
    }
    ui->age->addItems(age);

    init();

    //设置返回信号
    connect(ui->exit_btn, &QPushButton::clicked, [=](){
        emit this->choice_return();
    });

    //链接性别按钮
    connect(ui->boy_btn, &QRadioButton::clicked, [=](){
        ui->stackedWidget->setCurrentIndex(0);
    });

    connect(ui->girl_btn, &QRadioButton::clicked, [=](){
        ui->stackedWidget->setCurrentIndex(1);
    });

    //链接重置按钮
    connect(ui->clear_btn, &QPushButton::clicked, [=](){
        init();
    });

    Add_Manager* am = new Add_Manager;
    //链接更改按钮
    connect(ui->change_btn, &QPushButton::clicked, [=](){
        am->init();
        am->show();
    });

    connect(am, &Add_Manager::choice_return, this, [=](){
        am->close();
    });


    //链接添加按钮
    connect(ui->add_btn, &QPushButton::clicked, [=](){
        std::string Username = Student_Manager::ToString(ui->username_line->text());
        if(Student_Manager::unm_id.count(Username)) {
            QMessageBox::critical(this, "错误", "该用户名已被使用！");
            return;
        }
        std::string student_id = Student_Manager::ToString(ui->id_line->text());
        if(Student_Manager::num_stu.count(student_id)) {
            QMessageBox::critical(this, "错误", "该学号已被使用！");
            return;
        }
        std::string fir_psw = Student_Manager::ToString(ui->password_line->text());
        std::string sec_psw = Student_Manager::ToString(ui->password_check->text());
        if(fir_psw != sec_psw) {
            QMessageBox::critical(this, "错误", "两次密码输入不一致！");
            return;
        }
        if(fir_psw.length() < 8) {
            QMessageBox::critical(this, "错误", "密码长度需在8-15之间！");
            return;
        }
        int grade = ui->tabWidget->currentIndex() + 2;
        std::string name = Student_Manager::ToString(ui->name_line->text());
        std::string classname = Student_Manager::ToString(ui->classname_line->text());
        int sex;
        int age = ui->age->currentIndex() + 8;
        if(this->ui->boy_btn->isChecked()) {
            sex = 1;
        } else {
            sex = 2;
        }
        if(name.empty()) {
            QMessageBox::critical(this, "错误", "姓名不能为空！");
            return;
        }
        if(Username.empty()) {
            QMessageBox::critical(this, "错误", "用户名不能为空！");
            return;
        }
        if(student_id.empty()) {
            QMessageBox::critical(this, "错误", "学号不能为空！");
            return;
        }
        if(classname.empty()) {
            QMessageBox::critical(this, "错误", "班级不能为空！");
            return;
        }
        if(grade == 2) {
            if(ui->Pri_english->text().isEmpty()) {
                QMessageBox::critical(this, "错误", "英语成绩不能为空！");
                return;
            }
            if(ui->Pri_math->text().isEmpty()) {
                QMessageBox::critical(this, "错误", "数学成绩不能为空！");
                return;
            }
            if(ui->Pri_chinese->text().isEmpty()) {
                QMessageBox::critical(this, "错误", "语文成绩不能为空！");
                return;
            }
        } else if(grade == 3) {
            if(ui->Mid_english->text().isEmpty()) {
                QMessageBox::critical(this, "错误", "英语成绩不能为空！");
                return;
            }
            if(ui->Mid_math->text().isEmpty()) {
                QMessageBox::critical(this, "错误", "数学成绩不能为空！");
                return;
            }
            if(ui->Mid_chinese->text().isEmpty()) {
                QMessageBox::critical(this, "错误", "语文成绩不能为空！");
                return;
            }
            if(ui->Mid_geographic->text().isEmpty()) {
                QMessageBox::critical(this, "错误", "地理成绩不能为空！");
                return;
            }
            if(ui->Mid_history->text().isEmpty()) {
                QMessageBox::critical(this, "错误", "历史成绩不能为空！");
                return;
            }
        } else {
            if(ui->Col_professional->text().isEmpty()) {
                QMessageBox::critical(this, "错误", "专业成绩不能为空！");
                return;
            }
            if(ui->Col_english->text().isEmpty()) {
                QMessageBox::critical(this, "错误", "英语成绩不能为空！");
                return;
            }
            if(ui->Col_program_design->text().isEmpty()) {
                QMessageBox::critical(this, "错误", "程序设计成绩不能为空！");
                return;
            }
            if(ui->Col_Ad_math->text().isEmpty()) {
                QMessageBox::critical(this, "错误", "高等数学成绩不能为空！");
                return;
            }
        }
        int ret = QMessageBox::question(this, "选择", "请确定是否创建当前学生?", QMessageBox::Yes, QMessageBox::No);
        if(ret == QMessageBox::No) {
            QMessageBox::information(this, "提示", "已取消创建！");
            return;
        }
        Account* Person = new Account(Username, fir_psw, grade);//创建对应身份的学生账户，并推入到账户链表中
        if (Person) {//如果成功分配了内存
            Student_Manager::ID.push_back(Person);
            Student_Manager::unm_id.insert({Username, grade});//标记对应的学生类型
        } else {//内存分配失败，则提示用户，并结束函数，不执行以后的函数功能
            QMessageBox::critical(this, "警告", "内存不足,创建失败！");
            return;
        }
        Student_Manager::name_num.insert({name ,student_id});
        if(grade == 2) {
            int english = ui->Pri_english->text().toInt();
            int math = ui->Pri_math->text().toInt();
            int chinese = ui->Pri_chinese->text().toInt();
            Primary_student*stu = new Primary_student(student_id, name, sex, age, classname, grade, Username, english, math, chinese);
            if (!stu) {//内存不足
                QMessageBox::critical(this, "警告", "内存不足,创建失败！对应学生账户也将会销毁！");
                Student_Manager::unm_id.erase(Username);//删除该学生账户账号对应的记录
                delete Person;//删除账户
                Person = NULL;//置空
                return;
            } else {
                QMessageBox::information(this, "创建学生成功", "创建学生成功!");
                Student_Manager::PSTU.push_back(stu);//加入到学生链表里面
                Student_Manager::num_stu.insert({ student_id, stu });//关联学生学号和对应学生信息
            }
        } else if(grade == 3) {
            int english = ui->Mid_english->text().toInt();
            int math = ui->Mid_math->text().toInt();
            int chinese = ui->Mid_chinese->text().toInt();
            int geographic = ui->Mid_geographic->text().toInt();
            int history = ui->Mid_history->text().toInt();
            Middle_student*stu = new Middle_student(student_id, name, sex, age, classname, grade, Username, english, math, chinese, geographic, history);
            if (!stu) {//内存不足
                QMessageBox::critical(this, "警告", "内存不足,创建失败！对应学生账户也将会销毁！");
                Student_Manager::unm_id.erase(Username);//删除该学生账户账号对应的记录
                delete Person;//删除账户
                Person = NULL;//置空
                return;
            } else {
                QMessageBox::information(this, "创建学生成功", "创建学生成功!");
                Student_Manager::MSTU.push_back(stu);//加入到学生链表里面
                Student_Manager::num_stu.insert({ student_id, stu });//关联学生学号和对应学生信息
            }
        } else{
            int professional = ui->Col_professional->text().toInt();
            int english = ui->Col_english->text().toInt();
            int program_design = ui->Col_program_design->text().toInt();
            int advance_mathematics = ui->Col_Ad_math->text().toInt();
            College_student* stu= new College_student(student_id, name, sex, age, classname, grade, Username, professional, english, program_design, advance_mathematics);
            if (!stu) {//内存不足
                QMessageBox::critical(this, "警告", "内存不足,创建失败！对应学生账户也将会销毁！");
                Student_Manager::unm_id.erase(Username);//删除该学生账户账号对应的记录
                delete Person;//删除账户
                Person = NULL;//置空
                return;
            } else {
                QMessageBox::information(this, "创建学生成功", "创建学生成功!");
                Student_Manager::CSTU.push_back(stu);//加入到学生链表里面
                Student_Manager::num_stu.insert({ student_id, stu });//关联学生学号和对应学生信息
            }
        }
    });

    //利用正则表达式控制输入
    ui->password_line->setValidator(new QRegularExpressionValidator(QRegularExpression("[a-zA-Z0-9]+$")));
    ui->password_check->setValidator(new QRegularExpressionValidator(QRegularExpression("[a-zA-Z0-9]+$")));

    ui->Pri_chinese->setValidator(new QIntValidator(0, 100, this));
    ui->Pri_math->setValidator(new QIntValidator(0, 100, this));
    ui->Pri_english->setValidator(new QIntValidator(0, 100, this));

    ui->Mid_chinese->setValidator(new QIntValidator(0, 100, this));
    ui->Mid_math->setValidator(new QIntValidator(0, 100, this));
    ui->Mid_english->setValidator(new QIntValidator(0, 100, this));
    ui->Mid_geographic->setValidator(new QIntValidator(0, 100, this));
    ui->Mid_history->setValidator(new QIntValidator(0, 100, this));

    ui->Col_professional->setValidator(new QIntValidator(0, 100, this));
    ui->Col_english->setValidator(new QIntValidator(0, 100, this));
    ui->Col_program_design->setValidator(new QIntValidator(0, 100, this));
    ui->Col_Ad_math->setValidator(new QIntValidator(0, 100, this));

    //设置最多位数
    ui->password_line->setMaxLength(15);
    ui->password_check->setMaxLength(15);
}

Add_Person::~Add_Person() {
    delete ui;
}

void Add_Person::init() {
    //设置默认位置
    ui->stackedWidget->setCurrentIndex(0);

    //设置默认内容
    ui->age->setCurrentIndex(4);

    //设置默认按钮
    ui->boy_btn->setChecked(true);

    //设置默认tab
    ui->tabWidget->setCurrentIndex(0);

    ui->password_line->setText("");
    ui->password_check->setText("");
    ui->name_line->setText("");
    ui->username_line->setText("");
    ui->id_line->setText("");
    ui->classname_line->setText("");

    ui->Pri_chinese->setText("");
    ui->Pri_math->setText("");
    ui->Pri_english->setText("");

    ui->Mid_chinese->setText("");
    ui->Mid_math->setText("");
    ui->Mid_english->setText("");
    ui->Mid_geographic->setText("");
    ui->Mid_history->setText("");

    ui->Col_professional->setText("");
    ui->Col_english->setText("");
    ui->Col_program_design->setText("");
    ui->Col_Ad_math->setText("");
}

void Add_Person::paintEvent(QPaintEvent *){
    QPainter painter(this);
    QPixmap pix;
    pix.load(":/image/School.png");
    pix = pix.scaled(pix.width() * 0.2, pix.height() * 0.2);
    painter.drawPixmap(0, 10, pix);
}
