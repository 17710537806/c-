#ifndef DELETE_PERSON_H
#define DELETE_PERSON_H

#include <QWidget>
#include<QStandardItemModel>
#include<QMessageBox>
#include<string>
#include<student_manager.h>
#include<QPushButton>
#include<student_manager.h>
#include<account.h>
#include<my_messagebox.h>
#include<delete_manager.h>
#include<QPaintEvent>
#include<QPainter>
namespace Ui {
class Delete_Person;
}

class Delete_Person : public QWidget
{
    Q_OBJECT

public:
    explicit Delete_Person(QWidget *parent = nullptr);
    ~Delete_Person();

    void init();

    void Set();

signals:
    //设置返回信号
    void choice_return();

private:
    Ui::Delete_Person *ui;

    //画背景图
    void paintEvent(QPaintEvent *);
};

#endif // DELETE_PERSON_H
