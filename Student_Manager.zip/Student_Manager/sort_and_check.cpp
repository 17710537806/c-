#include "sort_and_check.h"
#include "qpainter.h"
#include "ui_sort_and_check.h"
#include<iostream>
sort_and_check::sort_and_check(QWidget *parent) : QWidget(parent), ui(new Ui::sort_and_check) {
    ui->setupUi(this);

    //设置图标
    setWindowIcon(QIcon(":/image/School.png"));

    //设置标题
    setWindowTitle("学生成绩管理系统");

    //添加下拉内容
    QStringList GradeList, Sort_way, Sort_mode;
    GradeList<<"全部显示"<<"只显示小学生"<<"只显示中学生"<<"只显示大学生"<<"只显示小学和中学生";
    ui->grade->addItems(GradeList);
    Sort_way<<"所有科总分"<<"语数英科总分"<<"地理历史总分"<<"语文"<<"数学"<<"英语"<<"地理"<<"历史"<<"专业"<<"程序设计"<<"高等数学"<<"学生按学号"<<"学生按班级"<<"账户按身份"<<"账户按用户名";
    ui->sort_way->addItems(Sort_way);
    Sort_mode<<"降序排列"<<"升序排列";
    ui->sort_mode->addItems(Sort_mode);

    init();

    connect(ui->grade, &QComboBox::currentIndexChanged, this, [=]() {
        int indexG = ui->grade->currentIndex();
        int indexM = ui->sort_mode->currentIndex();
        switch(indexG) {
            case 0: {
                if(indexM == 0) {
                    create_table(); create_IDtable();
                } else {
                    create_table(true, true, true, true); create_IDtable(true, true, true);
                }
                break;
            }
            case 1: {
                if(indexM == 0) {
                    create_table(true, false, false); create_IDtable(true, false, false);
                } else {
                    create_table(true, false, false, true); create_IDtable(true, false, false);
                }
                break;
            }
            case 2: {
                if(indexM == 0) {
                    create_table(false, true, false);create_IDtable(false, true, false);
                } else {
                    create_table(false, true, false, true);create_IDtable(false, true, false);
                }
                break;
            }
            case 3: {
                if(indexM == 0) {
                    create_table(false, false, true); create_IDtable(false, false, true);
                } else {
                    create_table(false, false, true, true); create_IDtable(false, false, true);
                }
                break;
            }
            case 4: {
                if(indexM == 0) {
                    create_table(true, true, false);create_IDtable(true, true, false);
                } else {
                    create_table(true, true, false, true);create_IDtable(true, true, false);
                }
                break;
            }
        }
    });

    connect(ui->Sort, &QPushButton::clicked,[=](){
        int indexS = ui->sort_way->currentIndex();
        Student_Manager::Sort_Function(indexS + 1);
        int indexG = ui->grade->currentIndex();
        int indexM = ui->sort_mode->currentIndex();
        switch(indexG) {
            case 0: {
                if(indexM == 0) {
                    create_table(); create_IDtable();
                } else {
                    create_table(true, true, true, true); create_IDtable(true, true, true);
                }
                break;
            }
            case 1: {
                if(indexM == 0) {
                    create_table(true, false, false); create_IDtable(true, false, false);
                } else {
                    create_table(true, false, false, true); create_IDtable(true, false, false);
                }
                break;
            }
            case 2: {
                if(indexM == 0) {
                    create_table(false, true, false);create_IDtable(false, true, false);
                } else {
                    create_table(false, true, false, true);create_IDtable(false, true, false);
                }
                break;
            }
            case 3: {
                if(indexM == 0) {
                    create_table(false, false, true); create_IDtable(false, false, true);
                } else {
                    create_table(false, false, true, true); create_IDtable(false, false, true);
                }
                break;
            }
            case 4: {
                if(indexM == 0) {
                    create_table(true, true, false);create_IDtable(true, true, false);
                } else {
                    create_table(true, true, false, true);create_IDtable(true, true, false);
                }
                break;
            }
        }
    });

    connect(ui->save_exc, &QPushButton::clicked, [=](){
        save();
    });

    connect(ui->exit_btn, &QPushButton::clicked,[=](){
        emit this->choice_return();
    });
}

sort_and_check::~sort_and_check() {
    delete ui;
}

void sort_and_check::save() {
    QString save_path = QFileDialog::getSaveFileName(this, "保存", "data_save","csv files(*.csv)");
    QString save_dir = QFileInfo(save_path).path();
    save_dir.append("/");
    QString save_name = QFileInfo(save_path).fileName();
    if(!save_path.isEmpty()) {
        QFile file(save_path);
        file.open(QIODevice::WriteOnly);
        QTextStream out(&file);
        out << "学历" << "," << "学号" << "," << "姓名" << "," <<"性别" << "," << "年龄" << "," << "班级" << "," << "用户名" << "," << "语文" << "," << "数学" << "," << "英语" << "," << "地理" << "," << "历史" << "," << "专业" << "," << "程设" << "," << "高数" << "," << "语数英总分" << "," << "选课总分" << "," <<"所有课总分" << "\n";
        for(int i = 0; i < ui->list_table->model()->rowCount(); ++i) {
            for(int j = 0; j < ui->list_table->model()->columnCount() - 1; ++j) {
                out << ui->list_table->model()->data(ui->list_table->model()->index(i,j)).toString() << ",";
            }
            out << ui->list_table->model()->data(ui->list_table->model()->index(i,ui->list_table->model()->columnCount() - 1)).toString() << "\n";
        }
        file.close();
        QMessageBox::information(this, "保存成功", "保存成功！");
    } else {
        return;
    }
    int index = ui->grade->currentIndex();
    if(index == 0) {
        std::string save_txt = Student_Manager::ToString(save_dir+save_name);
        save_txt[save_txt.length() - 1] = 't';
        save_txt[save_txt.length() - 2] = 'x';
        save_txt[save_txt.length() - 3] = 't';
        std::ofstream ofs(save_txt, std::ios::out);
        for(int i = 0; i < ui->list_table->model()->rowCount(); ++i) {
            QString id = ui->list_table->model()->data(ui->list_table->model()->index(i, 0)).toString();
            if(id == "小学生") {
                ofs << 2 << " ";
            } else if (id == "中学生") {
                ofs << 3 << " ";
            } else {
                ofs << 4 << " ";
            }
            for(int j = 1; j <= 2; ++ j) {
                ofs << Student_Manager::ToString(ui->list_table->model()->data(ui->list_table->model()->index(i, j)).toString()) << " ";
            }
            ofs << ((ui->list_table->model()->data(ui->list_table->model()->index(i, 3)).toString() == "男")? 1: 2) << " ";
            for(int j = 4; j <= 6; ++ j) {
                ofs << Student_Manager::ToString(ui->list_table->model()->data(ui->list_table->model()->index(i, j)).toString()) << " ";
            }
            ofs << std::endl;
        }
        ofs.close();
        std::string id(save_txt, 0, save_txt.length() - 4);
        id.append("id.txt");
        ofs.open(id, std::ios::out);
        for(auto i = Student_Manager::ID.begin(); i != Student_Manager::ID.end(); ++i) {
            ofs << (*i)->get_id() << " " << (*i)->get_username() << " " << (*i)->get_password() << std::endl;
        }
        ofs.close();
    }
}
void sort_and_check::create_table(bool Pri, bool Mid, bool Col, bool reverse){
    int count = 0;
    //设置表头
    QStringList headers;
    QStandardItemModel *models = new QStandardItemModel();
    headers<<"学历"<<"学号"<<"姓名"<<"性别"<<"年龄"<<"班级"<<"用户名"<<"语文"<<"数学"<<"英语"<<"地理"<<"历史"<<"专业"<<"程设"<<"高数"<<"语数英总分"<<"选课总分"<<"所有课总分";
    models->setHorizontalHeaderLabels(headers);
    count = 0;
    //添加数据，主表单部分
    if(Pri) {
        if(reverse) {
            auto Pbegin = Student_Manager::PSTU.rbegin();
            auto Pend = Student_Manager::PSTU.rend();
            for(auto i = Pbegin; i != Pend; ++i, ++count) {
                models->setItem(count, 0, new QStandardItem("小学生"));
                models->setItem(count, 1, new QStandardItem(QString::fromLocal8Bit((**i).get_Student_id())));
                models->setItem(count, 2, new QStandardItem(QString::fromLocal8Bit((**i).get_name())));
                models->setItem(count, 3, new QStandardItem((**i).get_sex() == 1?"男":"女"));
                models->setItem(count, 4, new QStandardItem(QString::number((**i).get_age())));
                models->setItem(count, 5, new QStandardItem(QString::fromLocal8Bit((**i).get_classname())));
                models->setItem(count, 6, new QStandardItem(QString::fromLocal8Bit((**i).get_username())));
                models->setItem(count, 7, new QStandardItem(QString::number((**i).get_Chinese())));
                models->setItem(count, 8, new QStandardItem(QString::number((**i).get_Math())));
                models->setItem(count, 9, new QStandardItem(QString::number((**i).get_English())));
                models->setItem(count, 15, new QStandardItem(QString::number((**i).get_pri_sum())));
                models->setItem(count, 17, new QStandardItem(QString::number((**i).get_pri_sum())));
            }
        } else {
            auto Pbegin = Student_Manager::PSTU.begin();
            auto Pend = Student_Manager::PSTU.end();
            for(auto i = Pbegin; i != Pend; ++i, ++count) {
                models->setItem(count, 0, new QStandardItem("小学生"));
                models->setItem(count, 1, new QStandardItem(QString::fromLocal8Bit((**i).get_Student_id())));
                models->setItem(count, 2, new QStandardItem(QString::fromLocal8Bit((**i).get_name())));
                models->setItem(count, 3, new QStandardItem((**i).get_sex() == 1?"男":"女"));
                models->setItem(count, 4, new QStandardItem(QString::number((**i).get_age())));
                models->setItem(count, 5, new QStandardItem(QString::fromLocal8Bit((**i).get_classname())));
                models->setItem(count, 6, new QStandardItem(QString::fromLocal8Bit((**i).get_username())));
                models->setItem(count, 7, new QStandardItem(QString::number((**i).get_Chinese())));
                models->setItem(count, 8, new QStandardItem(QString::number((**i).get_Math())));
                models->setItem(count, 9, new QStandardItem(QString::number((**i).get_English())));
                models->setItem(count, 15, new QStandardItem(QString::number((**i).get_pri_sum())));
                models->setItem(count, 17, new QStandardItem(QString::number((**i).get_pri_sum())));
            }
        }
    }
    if(Mid) {
        if(reverse) {
            auto Mbegin = Student_Manager::MSTU.rbegin();
            auto Mend = Student_Manager::MSTU.rend();
            for(auto i = Mbegin; i != Mend; ++i, ++count) {
                models->setItem(count, 0, new QStandardItem("中学生"));
                models->setItem(count, 1, new QStandardItem(QString::fromLocal8Bit((**i).get_Student_id())));
                models->setItem(count, 2, new QStandardItem(QString::fromLocal8Bit((**i).get_name())));
                models->setItem(count, 3, new QStandardItem((**i).get_sex() == 1?"男":"女"));
                models->setItem(count, 4, new QStandardItem(QString::number((**i).get_age())));
                models->setItem(count, 5, new QStandardItem(QString::fromLocal8Bit((**i).get_classname())));
                models->setItem(count, 6, new QStandardItem(QString::fromLocal8Bit((**i).get_username())));
                models->setItem(count, 7, new QStandardItem(QString::number((**i).get_Chinese())));
                models->setItem(count, 8, new QStandardItem(QString::number((**i).get_Math())));
                models->setItem(count, 9, new QStandardItem(QString::number((**i).get_English())));
                models->setItem(count, 10, new QStandardItem(QString::number((**i).get_Geographic())));
                models->setItem(count, 11, new QStandardItem(QString::number((**i).get_History())));
                models->setItem(count, 15, new QStandardItem(QString::number((**i).get_pri_sum())));
                models->setItem(count, 16, new QStandardItem(QString::number((**i).get_mid_sum())));
                models->setItem(count, 17, new QStandardItem(QString::number((**i).get_pri_sum()+(**i).get_mid_sum())));
            }
        } else {
            auto Mbegin = Student_Manager::MSTU.begin();
            auto Mend = Student_Manager::MSTU.end();
            for(auto i = Mbegin; i != Mend; ++i, ++count) {
                models->setItem(count, 0, new QStandardItem("中学生"));
                models->setItem(count, 1, new QStandardItem(QString::fromLocal8Bit((**i).get_Student_id())));
                models->setItem(count, 2, new QStandardItem(QString::fromLocal8Bit((**i).get_name())));
                models->setItem(count, 3, new QStandardItem((**i).get_sex() == 1?"男":"女"));
                models->setItem(count, 4, new QStandardItem(QString::number((**i).get_age())));
                models->setItem(count, 5, new QStandardItem(QString::fromLocal8Bit((**i).get_classname())));
                models->setItem(count, 6, new QStandardItem(QString::fromLocal8Bit((**i).get_username())));
                models->setItem(count, 7, new QStandardItem(QString::number((**i).get_Chinese())));
                models->setItem(count, 8, new QStandardItem(QString::number((**i).get_Math())));
                models->setItem(count, 9, new QStandardItem(QString::number((**i).get_English())));
                models->setItem(count, 10, new QStandardItem(QString::number((**i).get_Geographic())));
                models->setItem(count, 11, new QStandardItem(QString::number((**i).get_History())));
                models->setItem(count, 15, new QStandardItem(QString::number((**i).get_pri_sum())));
                models->setItem(count, 16, new QStandardItem(QString::number((**i).get_mid_sum())));
                models->setItem(count, 17, new QStandardItem(QString::number((**i).get_pri_sum()+(**i).get_mid_sum())));
            }
        }
    }
    if(Col) {
        if(reverse) {
            auto Cbegin = Student_Manager::CSTU.rbegin();
            auto Cend = Student_Manager::CSTU.rend();
            for(auto i = Cbegin; i != Cend; ++i, ++count) {
                models->setItem(count, 0, new QStandardItem("大学生"));
                models->setItem(count, 1, new QStandardItem(QString::fromLocal8Bit((**i).get_Student_id())));
                models->setItem(count, 2, new QStandardItem(QString::fromLocal8Bit((**i).get_name())));
                models->setItem(count, 3, new QStandardItem((**i).get_sex() == 1?"男":"女"));
                models->setItem(count, 4, new QStandardItem(QString::number((**i).get_age())));
                models->setItem(count, 5, new QStandardItem(QString::fromLocal8Bit((**i).get_classname())));
                models->setItem(count, 6, new QStandardItem(QString::fromLocal8Bit((**i).get_username())));
                models->setItem(count, 12, new QStandardItem(QString::number((**i).get_Professional())));
                models->setItem(count, 13, new QStandardItem(QString::number((**i).get_Program_design())));
                models->setItem(count, 9, new QStandardItem(QString::number((**i).get_English())));
                models->setItem(count, 14, new QStandardItem(QString::number((**i).get_Advanced_mathematics())));
                models->setItem(count, 17, new QStandardItem(QString::number((**i).get_all_sum())));
            }
        } else {
            auto Cbegin = Student_Manager::CSTU.begin();
            auto Cend = Student_Manager::CSTU.end();
            for(auto i = Cbegin; i != Cend; ++i, ++count) {
                models->setItem(count, 0, new QStandardItem("大学生"));
                models->setItem(count, 1, new QStandardItem(QString::fromLocal8Bit((**i).get_Student_id())));
                models->setItem(count, 2, new QStandardItem(QString::fromLocal8Bit((**i).get_name())));
                models->setItem(count, 3, new QStandardItem((**i).get_sex() == 1?"男":"女"));
                models->setItem(count, 4, new QStandardItem(QString::number((**i).get_age())));
                models->setItem(count, 5, new QStandardItem(QString::fromLocal8Bit((**i).get_classname())));
                models->setItem(count, 6, new QStandardItem(QString::fromLocal8Bit((**i).get_username())));
                models->setItem(count, 12, new QStandardItem(QString::number((**i).get_Professional())));
                models->setItem(count, 13, new QStandardItem(QString::number((**i).get_Program_design())));
                models->setItem(count, 9, new QStandardItem(QString::number((**i).get_English())));
                models->setItem(count, 14, new QStandardItem(QString::number((**i).get_Advanced_mathematics())));
                models->setItem(count, 17, new QStandardItem(QString::number((**i).get_all_sum())));
            }
        }
    }
    ui->list_table->horizontalHeader()->setSectionResizeMode(QHeaderView::ResizeToContents);
    ui->list_table->setModel(models);

    //将表单置为只读属性
    ui->list_table->setEditTriggers(QAbstractItemView::NoEditTriggers);

    int index = ui->sort_way->currentIndex();

    //添加数据，副表单部分
    if(index >= 11) {//只有关于分数的排序才进行更改
        return;
    }
    QStandardItemModel *left_model = new QStandardItemModel();
    QStringList left_header,left_headers;
    left_header<<"学号"<<"姓名";
    left_header.append(ui->sort_way->currentText());
    left_model->setHorizontalHeaderLabels(left_header);
    for(int i = 0; i < count; ++i) {
        left_headers.append(QString::number(i+1,10));
    }
    ui->left_table->horizontalHeader()->setSectionResizeMode(QHeaderView::ResizeToContents);
    left_model->setVerticalHeaderLabels(left_headers);
    if(index == 0) {
        index = 17;
    } else if(index <= 2) {
        index += 14;
    } else {
        index += 4;
    }
    for(int i = 0; i < count; ++i) {
        left_model->setItem(i, 0, new QStandardItem(models->data(models->index(i, 1)).toString()));
        left_model->setItem(i, 1, new QStandardItem(models->data(models->index(i, 2)).toString()));
        left_model->setItem(i, 2, new QStandardItem(models->data(models->index(i, index)).toString()));
    }
    ui->left_table->setModel(left_model);
    //将表单置为只读属性
    ui->left_table->setEditTriggers(QAbstractItemView::NoEditTriggers);
}

void sort_and_check::create_IDtable(bool Pri, bool Mid, bool Col) {
    QStandardItemModel *right_model = new QStandardItemModel();
    QStringList right_header;
    right_header<<"账户身份"<<"用户名";
    right_model->setHorizontalHeaderLabels(right_header);
    ui->right_table->horizontalHeader()->setSectionResizeMode(QHeaderView::ResizeToContents);
    ui->right_table->setModel(right_model);
    int k = 0;
    for(auto i = Student_Manager::ID.begin(); i!=Student_Manager::ID.end(); ++i) {
        QString id;
        switch((**i).get_id()) {
            case 1:id="教师";break;
            case 2:id="小学生";break;
            case 3:id="中学生";break;
            case 4:id="大学生";break;
        }
        if((Pri && (**i).get_id() == 2) || (**i).get_id() == 1) {
            right_model->setItem(k, 0, new QStandardItem(id));
            right_model->setItem(k, 1, new QStandardItem(QString::fromLocal8Bit((**i).get_username())));
            ++k;
        } else if(Mid && (**i).get_id() == 3) {
            right_model->setItem(k, 0, new QStandardItem(id));
            right_model->setItem(k, 1, new QStandardItem(QString::fromLocal8Bit((**i).get_username())));
            ++k;
        } else if(Col && (**i).get_id() == 4) {
            right_model->setItem(k, 0, new QStandardItem(id));
            right_model->setItem(k, 1, new QStandardItem(QString::fromLocal8Bit((**i).get_username())));
            ++k;
        }
    }
    //将表单置为只读属性
    ui->right_table->setEditTriggers(QAbstractItemView::NoEditTriggers);
}
void sort_and_check::statistics(){
    QStandardItemModel *bottom_model = new QStandardItemModel();
    QStringList bottom_header;
    bottom_header<<"学生总计"<<"账户总计"<<"小学生总计"<<"中学生总计"<<"大学生总计"<<"老师总计"<<"小学中学语数英成绩总分和"<<"均分"<<"中学成绩总分和"<<"均分"<<"大学成绩总分和"<<"均分"<<"小学语数英成绩总分和"<<"均分"<<"中学语数英成绩总分和"<<"均分"<<"中学选科成绩总分和"<<"均分"<<"小学语文成绩总分和"<<"均分"<<"小学数学成绩总分和"<<"均分"<<"小学英语成绩总分和"<<"均分"<<"中学语文成绩总分和"<<"均分"<<"中学数学成绩总分和"<<"均分"<<"中学英语成绩总分和"<<"均分"<<"中学历史成绩总分和"<<"均分"<<"中学地理成绩总分和"<<"均分"<<"大学专业成绩总分和"<<"均分"<<"大学英语成绩总分和"<<"均分"<<"大学程序设计成绩总分和"<<"均分"<<"大学高等数学成绩总分和"<<"均分";
    bottom_model->setHorizontalHeaderLabels(bottom_header);
    ui->bottom_table->horizontalHeader()->setSectionResizeMode(QHeaderView::ResizeToContents);
    ui->bottom_table->setModel(bottom_model);
    bottom_model->setItem(0, 0, new QStandardItem(QString::number(Student_Manager::PSTU.size() + Student_Manager::MSTU.size() + Student_Manager::CSTU.size())));
    bottom_model->setItem(0, 1, new QStandardItem(QString::number(Student_Manager::ID.size())));
    bottom_model->setItem(0, 2, new QStandardItem(QString::number(Student_Manager::PSTU.size())));
    bottom_model->setItem(0, 3, new QStandardItem(QString::number(Student_Manager::MSTU.size())));
    bottom_model->setItem(0, 4, new QStandardItem(QString::number(Student_Manager::CSTU.size())));
    bottom_model->setItem(0, 5, new QStandardItem(QString::number(Student_Manager::ID.size() - Student_Manager::MSTU.size() - Student_Manager::PSTU.size() - Student_Manager::CSTU.size())));
    bottom_model->setItem(0, 6, new QStandardItem(QString::number(Primary_class::get_All_sum())));
    bottom_model->setItem(0, 7, new QStandardItem(QString::number((double)Primary_class::get_All_sum() / (Student_Manager::PSTU.size() + Student_Manager::MSTU.size()),'f',2)));
    bottom_model->setItem(0, 8, new QStandardItem(QString::number(Middle_class::get_All_sum() + Middle_student::get_All_sum())));
    bottom_model->setItem(0, 9, new QStandardItem(QString::number((double)(Middle_class::get_All_sum() + Middle_student::get_All_sum()) / Student_Manager::MSTU.size(),'f',2)));
    bottom_model->setItem(0, 10, new QStandardItem(QString::number(College_class::get_All_sum())));
    bottom_model->setItem(0, 11, new QStandardItem(QString::number((double)College_class::get_All_sum() / Student_Manager::CSTU.size(),'f',2)));
    bottom_model->setItem(0, 12, new QStandardItem(QString::number(Primary_class::get_All_sum() - Middle_student::get_All_sum())));
    bottom_model->setItem(0, 13, new QStandardItem(QString::number((double)(Primary_class::get_All_sum() - Middle_student::get_All_sum()) / Student_Manager::PSTU.size(),'f',2)));
    bottom_model->setItem(0, 14, new QStandardItem(QString::number(Middle_student::get_All_sum())));
    bottom_model->setItem(0, 15, new QStandardItem(QString::number((double)Middle_student::get_All_sum() / Student_Manager::MSTU.size(),'f',2)));
    bottom_model->setItem(0, 16, new QStandardItem(QString::number(Middle_class::get_All_sum())));
    bottom_model->setItem(0, 17, new QStandardItem(QString::number((double)Middle_class::get_All_sum() /  Student_Manager::MSTU.size(),'f',2)));
    bottom_model->setItem(0, 18, new QStandardItem(QString::number(Primary_class::get_Chinese_sum() - Middle_student::get_Chinese_sum())));
    bottom_model->setItem(0, 19, new QStandardItem(QString::number((double)(Primary_class::get_Chinese_sum() - Middle_student::get_Chinese_sum()) / Student_Manager::PSTU.size(),'f',2)));
    bottom_model->setItem(0, 20, new QStandardItem(QString::number(Primary_class::get_Math_sum() - Middle_student::get_Math_sum())));
    bottom_model->setItem(0, 21, new QStandardItem(QString::number((double)(Primary_class::get_Math_sum() - Middle_student::get_Math_sum()) / Student_Manager::PSTU.size(),'f',2)));
    bottom_model->setItem(0, 22, new QStandardItem(QString::number(Primary_class::get_English_sum() - Middle_student::get_English_sum())));
    bottom_model->setItem(0, 23, new QStandardItem(QString::number((double)(Primary_class::get_English_sum() - Middle_student::get_English_sum()) / Student_Manager::PSTU.size(),'f',2)));
    bottom_model->setItem(0, 24, new QStandardItem(QString::number(Middle_student::get_Chinese_sum())));
    bottom_model->setItem(0, 25, new QStandardItem(QString::number((double)Middle_student::get_Chinese_sum() / Student_Manager::MSTU.size(),'f',2)));
    bottom_model->setItem(0, 26, new QStandardItem(QString::number(Middle_student::get_Math_sum())));
    bottom_model->setItem(0, 27, new QStandardItem(QString::number((double)Middle_student::get_Math_sum() / Student_Manager::MSTU.size(),'f',2)));
    bottom_model->setItem(0, 28, new QStandardItem(QString::number(Middle_student::get_English_sum())));
    bottom_model->setItem(0, 29, new QStandardItem(QString::number((double)Middle_student::get_English_sum() / Student_Manager::MSTU.size(),'f',2)));
    bottom_model->setItem(0, 30, new QStandardItem(QString::number(Middle_class::get_Geographic_sum())));
    bottom_model->setItem(0, 31, new QStandardItem(QString::number((double)Middle_class::get_Geographic_sum() / Student_Manager::MSTU.size(),'f',2)));
    bottom_model->setItem(0, 32, new QStandardItem(QString::number(Middle_class::get_History_sum())));
    bottom_model->setItem(0, 33, new QStandardItem(QString::number((double)Middle_class::get_History_sum() / Student_Manager::MSTU.size(),'f',2)));
    bottom_model->setItem(0, 34, new QStandardItem(QString::number(College_class::get_Professional_sum())));
    bottom_model->setItem(0, 35, new QStandardItem(QString::number((double)College_class::get_Professional_sum() / Student_Manager::CSTU.size(),'f',2)));
    bottom_model->setItem(0, 36, new QStandardItem(QString::number(College_class::get_English_sum())));
    bottom_model->setItem(0, 37, new QStandardItem(QString::number((double)College_class::get_English_sum() / Student_Manager::CSTU.size(),'f',2)));
    bottom_model->setItem(0, 38, new QStandardItem(QString::number(College_class::get_Program_design_sum())));
    bottom_model->setItem(0, 39, new QStandardItem(QString::number((double)College_class::get_Program_design_sum() / Student_Manager::CSTU.size(),'f',2)));
    bottom_model->setItem(0, 40, new QStandardItem(QString::number(College_class::get_Advanced_mathematics_sum())));
    bottom_model->setItem(0, 41, new QStandardItem(QString::number((double)College_class::get_Advanced_mathematics_sum() / Student_Manager::CSTU.size(),'f',2)));

    //设置居中
    for (int i = 0; i < 42; ++i) {
        bottom_model->item(0, i)->setTextAlignment(Qt::AlignCenter);
    }

    //将表单置为只读属性
    ui->bottom_table->setEditTriggers(QAbstractItemView::NoEditTriggers);
}

void sort_and_check::paintEvent(QPaintEvent *){
    QPainter painter(this);
    QPixmap pix;
    pix.load(":/image/School.png");
    pix = pix.scaled(pix.width() * 0.2, pix.height() * 0.2);
    painter.drawPixmap(0, 10, pix);
}

void sort_and_check::init() {
    //先进行排序
    Student_Manager::Sort_Function(1);

    //设置默认内容
    ui->grade->setCurrentIndex(0);
    ui->sort_way->setCurrentIndex(0);
    ui->sort_mode->setCurrentIndex(0);

    //初始化表单
    create_table();
    create_IDtable();
    statistics();
}
