#ifndef ADD_PERSON_H
#define ADD_PERSON_H

#include <QWidget>
#include<QStringList>
#include<Image_button.h>
#include<QRegularExpressionValidator>
#include<string>
#include<account.h>
#include<primary_student.h>
#include<middle_student.h>
#include<college_student.h>
#include<student_manager.h>
#include<QMessageBox>
#include<QPaintEvent>
#include<QPainter>
#include<add_manager.h>
namespace Ui {
class Add_Person;
}

class Add_Person : public QWidget
{
    Q_OBJECT

public:
    explicit Add_Person(QWidget *parent = nullptr);
    ~Add_Person();

    void init();

signals:
    //设置返回信号
    void choice_return();

private:
    Ui::Add_Person *ui;

    //画背景图
    void paintEvent(QPaintEvent *);
};

#endif // ADD_PERSON_H
