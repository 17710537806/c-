#ifndef MYTABLEVIEW_H
#define MYTABLEVIEW_H
#include<QTableView>
#include "QMouseEvent"
class mytableview : public QTableView
{
    Q_OBJECT
public:
    mytableview(QWidget *parent= nullptr);
    static int CurRow;
signals:

    void add();

    void remove();
protected:
    QModelIndex index;
    void mousePressEvent(QMouseEvent *event);
    static QMenu* mu;
};

#endif // MYTABLEVIEW_H
