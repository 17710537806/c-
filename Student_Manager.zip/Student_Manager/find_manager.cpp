#include "find_manager.h"
#include "ui_find_manager.h"

Find_Manager::Find_Manager(QWidget *parent) : QWidget(parent), ui(new Ui::Find_Manager) {
    ui->setupUi(this);

    //设置图标
    setWindowIcon(QIcon(":/image/School.png"));

    //设置标题
    setWindowTitle("学生成绩管理系统");

    init();

    connect(ui->exit_btn, &QPushButton::clicked,[=]() {
        emit this->choice_return();
    });

    connect(ui->check_btn, &QPushButton::clicked,[=]() {
        if(ui->get_line->text().isEmpty()) {
            QMessageBox::critical(this, "警告", "查找内容不能为空！");
            return;
        }
        std::string username = Student_Manager::ToString(ui->get_line->text());
        if (Student_Manager::unm_id.count(username)) {//哈希表内有该成员，避免使用[]造成不必要的插入
            switch (Student_Manager::unm_id[username]) {//用键值查找
                case 1: QMessageBox::information(this, "身份", "该账户身份为老师"); break;
                case 2: QMessageBox::information(this, "身份", "该账户身份为小学生"); break;
                case 3: QMessageBox::information(this, "身份", "该账户身份为中学生"); break;
                case 4: QMessageBox::information(this, "身份", "该账户身份为大学生"); break;
            }
        }
        else {//哈希表内没有该成员
            QMessageBox::critical(this, "错误", "查询不到该账户！");
        }
    });
}

Find_Manager::~Find_Manager() {
    delete ui;
}

void Find_Manager::init() {
    ui->get_line->setText("");
}

void Find_Manager::paintEvent(QPaintEvent *){
    QPainter painter(this);
    QPixmap pix;
    pix.load(":/image/School.png");
    pix = pix.scaled(pix.width() * 0.1, pix.height() * 0.1);
    painter.drawPixmap(0, 10, pix);
}
