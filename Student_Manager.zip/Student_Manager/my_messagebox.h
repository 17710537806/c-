#ifndef MY_MESSAGEBOX_H
#define MY_MESSAGEBOX_H

#include <QWidget>
#include<QPaintEvent>
#include<QPainter>
#include<QMessageBox>
namespace Ui {
class My_messageBox;
}

class My_messageBox : public QWidget
{
    Q_OBJECT

public:
    explicit My_messageBox(QWidget *parent = nullptr);
    ~My_messageBox();

signals:
    //设置返回信号
    void choice_return();

    //设置添加信号
    void add();

    //设置取消信号
    void exit();

private:
    Ui::My_messageBox *ui;

    //画背景图
    void paintEvent(QPaintEvent *);
};

#endif // MY_MESSAGEBOX_H
