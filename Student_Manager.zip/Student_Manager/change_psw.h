#ifndef CHANGE_PSW_H
#define CHANGE_PSW_H

#include <QWidget>
#include<QPaintEvent>
#include<QPainter>
#include<QRegularExpressionValidator>
#include<QMessageBox>
#include<student_manager.h>
namespace Ui {
class Change_psw;
}

class Change_psw : public QWidget
{
    Q_OBJECT

public:
    explicit Change_psw(QWidget *parent = nullptr);
    ~Change_psw();

    void init();

signals:

    //设置返回信号
    void choice_return();

private:
    Ui::Change_psw *ui;

    //画背景图
    void paintEvent(QPaintEvent *);
};

#endif // CHANGE_PSW_H
