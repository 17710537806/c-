#include "account.h"
Account::Account(std::string Username, std::string psw,int Id) {
    username = Username, password = psw, id = Id;
}
int Account::get_id() {
    return id;
}
std::string Account::get_username(){
    return username;
}
std::string Account::get_password(){
    return password;
}
