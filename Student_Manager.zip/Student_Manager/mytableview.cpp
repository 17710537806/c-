#include "mytableview.h"
#include<QMenu>
#include<QDebug>
mytableview::mytableview(QWidget *parent) :QTableView(parent){
    this->setFocusPolicy(Qt::NoFocus);
    mu = new QMenu;
    QAction* Action1 = new QAction("添加行");
    QAction* Action2 = new QAction("删除行");
    mu->addAction(Action1);
    mu->addAction(Action2);
    connect(Action1, &QAction::triggered,[=](){
        emit this->add();
    });
    connect(Action2, &QAction::triggered,[=](){
        emit this->remove();
    });
}

QMenu* mytableview::mu = nullptr;
int mytableview::CurRow = 0;

void mytableview::mousePressEvent(QMouseEvent *event)
{
    if( event->button()== Qt::RightButton) {
        setCurrentIndex(QModelIndex());
        QTableView::mousePressEvent(event);//这里需要重新获取一次pressevent，否则获取不到currentIndex()
        index = currentIndex();
        CurRow = index.row();
        mu->exec(cursor().pos());
    } else {
        setCurrentIndex(QModelIndex());
        QTableView::mousePressEvent(event);//这里需要重新获取一次pressevent，否则获取不到currentIndex()
        index = currentIndex();
    }
}
