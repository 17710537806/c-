#ifndef FIND_PERSON_H
#define FIND_PERSON_H

#include <QWidget>
#include<QPushButton>
#include<QString>
#include<QStringList>
#include<student_manager.h>
#include<QMessageBox>
#include<QStandardItemModel>
#include<vector>
#include<string>
#include<find_manager.h>
namespace Ui {
class Find_Person;
}

class Find_Person : public QWidget
{
    Q_OBJECT

public:
    explicit Find_Person(QWidget *parent = nullptr);
    ~Find_Person();

    void init();

    void Set();

    void init_table();

    void get_table(bool Pri = true, bool Mid = true, bool Col = true);
signals:
    //设置返回信号
    void choice_return();

private:
    Ui::Find_Person *ui;
    std::vector<std::string> check;

    //画背景图
    void paintEvent(QPaintEvent *);
};

#endif // FIND_PERSON_H
