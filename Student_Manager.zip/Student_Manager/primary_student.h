#ifndef PRIMARY_STUDENT_H
#define PRIMARY_STUDENT_H
#include<student.h>
#include<primary_class.h>
#include<string>
class Primary_student :public Student, public Primary_class{//继承学生类
public:
    //有参构造
    Primary_student(std::string student_id,std::string Name,int Sex,int Age,std::string Classname,int Grade,std::string Username,int english,int math,int chinese);
};

#endif // PRIMARY_STUDENT_H
