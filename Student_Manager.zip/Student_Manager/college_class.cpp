#include "college_class.h"

College_class::College_class(int professional,int english,int program_design,int advanced_mathematics){
    Professional = professional, English = english, Program_design = program_design, Advanced_mathematics = advanced_mathematics;
    Professional_sum += professional, English_sum += English, Program_design_sum += Program_design, Advanced_mathematics_sum += Advanced_mathematics;//记录到总和中
}
College_class::~College_class() {
    Professional_sum -= Professional, English_sum -= English, Program_design_sum -= Program_design, Advanced_mathematics_sum -= Advanced_mathematics;//消除对成绩总和的影响
}
int College_class::get_Professional() {
    return Professional;
}
int College_class::get_English() {
    return English;
}
int College_class::get_Program_design() {
    return Program_design;
}
int College_class::get_Advanced_mathematics() {
    return Advanced_mathematics;
}
int College_class::get_all_sum() {
    return Professional + English + Program_design + Advanced_mathematics;
}
int College_class::Professional_sum = 0;
int College_class::English_sum = 0;
int College_class::Program_design_sum = 0;
int College_class::Advanced_mathematics_sum = 0;
int College_class::get_Professional_sum() {
    return Professional_sum;
}
int College_class::get_English_sum() {
    return English_sum;
}
int College_class::get_Program_design_sum() {
    return Program_design_sum;
}
int College_class::get_Advanced_mathematics_sum() {
    return Advanced_mathematics_sum;
}
int College_class::get_All_sum() {
    return Professional_sum + English_sum + Program_design_sum + Advanced_mathematics_sum;
}
