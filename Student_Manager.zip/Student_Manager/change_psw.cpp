#include "change_psw.h"
#include "ui_change_psw.h"

Change_psw::Change_psw(QWidget *parent) : QWidget(parent), ui(new Ui::Change_psw){
    ui->setupUi(this);

    //设置图标
    setWindowIcon(QIcon(":/image/School.png"));

    //设置标题
    setWindowTitle("学生成绩管理系统");

    //利用正则表达式控制输入
    ui->new_fir_psw->setValidator(new QRegularExpressionValidator(QRegularExpression("[a-zA-Z0-9]+$")));
    ui->new_sec_psw->setValidator(new QRegularExpressionValidator(QRegularExpression("[a-zA-Z0-9]+$")));

    //设置最多位数
    ui->new_fir_psw->setMaxLength(15);
    ui->new_sec_psw->setMaxLength(15);

    connect(ui->exit_btn, &QPushButton::clicked, this, [=](){
        emit this->choice_return();
    });

    connect(ui->change_btn, &QPushButton::clicked, this, [=](){
        if(Student_Manager::Password != Student_Manager::ToString(ui->old_psw->text())) {
            QMessageBox::critical(this, "警告", "旧密码错误");
            return;
        }
        if(ui->new_fir_psw->text() != ui->new_sec_psw->text()) {
            QMessageBox::critical(this, "警告", "两次密码输入不一致");
            return;
        }
        if(ui->new_fir_psw->text().length() < 8) {
            QMessageBox::critical(this, "警告", "密码需在8-15位之间");
            return;
        }
        std::string username = Student_Manager::Username;
        int ret = QMessageBox::question(this, "选择", "请确认是否修改自身账户密码?", QMessageBox::Yes, QMessageBox::No);
        if(ret == QMessageBox::No) {
            QMessageBox::information(this, "提示", "已取消修改！");
            return;
        }
        std::string password = Student_Manager::ToString(ui->new_fir_psw->text());
        Account* Ac = new Account(username, password, Student_Manager::unm_id[username]);//添加账号
        Student_Manager::remove(Student_Manager::ID, username);
        Student_Manager::ID.push_back(Ac);
        QMessageBox::information(this, "成功", "修改密码成功！");
    });
}

Change_psw::~Change_psw(){
    delete ui;
}

void Change_psw::init() {
    //设置默认tab
    ui->new_fir_psw->setText("");
    ui->new_sec_psw->setText("");
    ui->old_psw->setText("");
}

void Change_psw::paintEvent(QPaintEvent *){
    QPainter painter(this);
    QPixmap pix;
    pix.load(":/image/School.png");
    pix = pix.scaled(pix.width() * 0.1, pix.height() * 0.1);
    painter.drawPixmap(0, 5, pix);
}
