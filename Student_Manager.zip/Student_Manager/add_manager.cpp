#include "add_manager.h"
#include "ui_add_manager.h"

Add_Manager::Add_Manager(QWidget *parent) : QWidget(parent), ui(new Ui::Add_Manager) {
    ui->setupUi(this);

    //设置图标
    setWindowIcon(QIcon(":/image/School.png"));

    //设置标题
    setWindowTitle("学生成绩管理系统");

    //进行初始化
    init();

    //设置最多位数
    ui->Password_fir_line->setMaxLength(15);
    ui->Password_sec_line->setMaxLength(15);

    //利用正则表达式控制输入
    ui->Password_fir_line->setValidator(new QRegularExpressionValidator(QRegularExpression("[a-zA-Z0-9]+$")));
    ui->Password_sec_line->setValidator(new QRegularExpressionValidator(QRegularExpression("[a-zA-Z0-9]+$")));

    connect(ui->exit_btn, &QPushButton::clicked, [=](){
        emit this->choice_return();
    });

    connect(ui->add_btn, &QPushButton::clicked, [=](){
        if(ui->Username_line->text().isEmpty()) {
            QMessageBox::critical(this, "错误", "用户名不能为空！");
            return;
        }
        std::string Username = Student_Manager::ToString(ui->Username_line->text());
        if (Student_Manager::unm_id.count(Username)) {//如果用户名存在
            QMessageBox::critical(this, "错误", "该用户名已被使用!");
            return;//直接结束函数
        }
        if(ui->Password_fir_line->text().isEmpty()) {
            QMessageBox::critical(this, "错误", "密码不能为空！");
            return;
        }
        if(ui->Password_sec_line->text() != ui->Password_fir_line->text()) {
            QMessageBox::critical(this, "错误", "两次密码输入不一致！");
            return;
        }
        std::string psw = Student_Manager::ToString(ui->Password_fir_line->text());
        if(psw.length() < 8) {
            QMessageBox::critical(this, "错误", "密码长度需在8-15之间！");
            return;
        }
        int ret = QMessageBox::question(this, "选择", "确定是否创建当前账户?", QMessageBox::Yes, QMessageBox::No);
        if(ret == QMessageBox::No) {
            QMessageBox::information(this, "提示", "已取消创建！");
            return;
        }
        Account* Person = new Account(Username, psw, 1);//创建身份为老师，其他信息如上的账户，并加入到链表中
        if (Person) {//如果成功分配了内存
            QMessageBox::information(this, "成功", "创建成功！");
            Student_Manager::ID.push_back(Person);
            Student_Manager::unm_id.insert({Username, 1});//标记该用户名使用者为老师
        }
        else {//内存分配失败
            QMessageBox::critical(this, "警告", "内存不足,创建失败！");
        }
    });
}

Add_Manager::~Add_Manager() {
    delete ui;
}

void Add_Manager::init() {
    //设置默认tab
    ui->Password_fir_line->setText("");
    ui->Password_sec_line->setText("");
    ui->Username_line->setText("");
}

void Add_Manager::paintEvent(QPaintEvent *){
    QPainter painter(this);
    QPixmap pix;
    pix.load(":/image/School.png");
    pix = pix.scaled(pix.width() * 0.1, pix.height() * 0.1);
    painter.drawPixmap(0, 5, pix);
}
