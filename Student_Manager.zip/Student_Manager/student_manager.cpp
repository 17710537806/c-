#include "student_manager.h"
#include "ui_student_manager.h"
#include<menu.h>
#include<QPainter>
#include<QPushButton>
#include<fstream>
#include<list>
#include<unordered_map>
#include<string>
#include<QMessageBox>
Student_Manager::Student_Manager(QWidget *parent): QMainWindow(parent), ui(new Ui::Student_Manager){
    ui->setupUi(this);
    //设置主场景

    //设置固定大小
    setFixedSize(1200, 800);

    //设置图标
    setWindowIcon(QIcon(":/image/School.png"));

    //设置标题
    setWindowTitle("学生成绩管理系统");

    //读入用户数据进行初始化
    init();

    //创建菜单界面
    Menu* menu = new Menu;
    Student_Menu* mu = new Student_Menu;

    //去除groupBox类的白边
    ui->groupBox->setStyleSheet("QGroupBox{border:none}");

    //监听返回
    connect(menu, &Menu::choice_return, this, [=](){
        menu->close();
        init();
        this->show();
        this->setGeometry(menu->geometry());//设置位置保持一致
    });

    connect(mu, &Student_Menu::choice_return, this, [=](){
        mu->close();
        init();
        this->show();
        this->setGeometry(mu->geometry());//设置位置保持一致
    });

    //监听保存
    connect(menu, &Menu::save, this, [=](){
        save();
        save_id_list();
    });

    connect(mu, &Student_Menu::save, this, [=](){
        save_id_list();
    });

    //监听读取
    connect(menu, &Menu::init, this, [=](){
        init();
        QMessageBox::information(this, "成功", "读取成功！");
    });

    connect(menu, &Menu::read_new, this, [=](){
        init(false);
    });

    connect(mu, &Student_Menu::init, this, [=](){
        init();
    });

    //设置身份默认选项
    ui->btn_teacher->setChecked(true);

    //设置登录选项
    connect(ui->login, &QPushButton::clicked, [=](){
        /*this->hide();
        menu->show();
        menu->setGeometry(this->geometry());//设置位置保持一致*/
        QString username = this->ui->UsernameLine->text();
        QString password = this->ui->PasswordLine->text();
        int ID;
        if(this->ui->btn_teacher->isChecked()){//判断选中身份
            ID = 1;
        } else if (this->ui->btn_Pri_stu->isChecked()) {
            ID = 2;
        } else if (this->ui->btn_Mid_stu->isChecked()) {
            ID = 3;
        } else if (this->ui->btn_Col_stu->isChecked()) {
            ID = 4;
        }
        if(check(ID, ToString(username), ToString(password))){//进行登录核验
            Username = ToString(username);
            Password = ToString(password);
            this->hide();
            if(ID == 1) {
                menu->show();
                menu->setGeometry(this->geometry());//设置位置保持一致
            } else {
                mu->show();
                mu->setGeometry(this->geometry());//设置位置保持一致
            }
        } else {
            QMessageBox::critical(this,"警告", "身份选择错误或账户/密码/输入错误");
        }
    });

    //设置退出选项
    connect(ui->exit, &QPushButton::clicked, [=](){
        this->close();
    });

}
Student_Manager::~Student_Manager(){
    delete ui;
}


//静态成员变量初始化
std::list<Account*> Student_Manager::ID;
std::unordered_map<std::string, int> Student_Manager::unm_id;
std::list<Primary_student*> Student_Manager::PSTU;
std::list<Middle_student*> Student_Manager::MSTU;
std::list<College_student*> Student_Manager::CSTU;
std::multiset<STU_NAME> Student_Manager::name_num;
std::unordered_map<std::string, Student*> Student_Manager::num_stu;
std::string Student_Manager::Username = "";
std::string Student_Manager::Password = "";

void Student_Manager::paintEvent(QPaintEvent *){
    QPainter painter(this);
    QPixmap pix;
    pix.load(":/image/School_badge.png");
    pix = pix.scaled(pix.width() * 0.5, pix.height() * 0.5);
    painter.drawPixmap(0, 10, pix);
}

template<typename Type>
void Student_Manager::Clear_list(std::list<Type>& lt) {
    for (auto i = lt.begin(); i != lt.end(); ++i) {
        delete* i;//释放内存
        *i = NULL;//置空
    }
}

void Student_Manager::Clear_All_List() {
    Clear_list(PSTU), Clear_list(MSTU), Clear_list(CSTU), Clear_list(ID);
}

void Student_Manager::init(bool flag){
    Clear_All_List();
    PSTU.clear(), MSTU.clear(), CSTU.clear(), name_num.clear(), num_stu.clear(),unm_id.clear(), ID.clear();
    int id;//定义需要输入的内容
    std::string username, password;
    std::ifstream ifs_user;
    if(!flag) {
        QString save_path = QFileDialog::getOpenFileName(this, "读取用户文件", "", "files(*.txt)");
        ifs_user.open(ToString(save_path), std::ios::in | std::ios::binary);
    } else {
        ifs_user.open(User_File, std::ios::in | std::ios::binary);
    }
    if (!ifs_user.is_open()) {//如果文件打不开
        QMessageBox::critical(this,"警告", "用户文件不存在!");
        ifs_user.close();
        return;//结束函数
    }
    while (ifs_user >> id && ifs_user >> username && ifs_user >> password) {
        ID.push_back(new Account(username, password, id));//添加用户
        unm_id.insert({ username,id });//关联用户和身份
    }
    ifs_user.close();
    std::ifstream ifs_Pri;
    if(!flag) {
        QString save_path = QFileDialog::getOpenFileName(this, "读取小学文件", "", "files(*.txt)");
        ifs_Pri.open(ToString(save_path), std::ios::in | std::ios::binary);
    } else {
        ifs_Pri.open(Pri_File, std::ios::in | std::ios::binary);
    }
    if (!ifs_Pri.is_open()) {//如果文件打不开
        QMessageBox::critical(this,"警告", "小学生文件不存在!");
        ifs_Pri.close();
        return;//结束函数
    }
    std::string student_id, name, classname, Username;//定义需要输入的内容
    int sex, age, professional, english, program_design, advance_mathematics, chinese, math, English, geographic, history;
    while (ifs_Pri >> student_id && ifs_Pri >> name && ifs_Pri >> sex && ifs_Pri >> age && ifs_Pri >> classname && ifs_Pri >> Username && ifs_Pri >> chinese && ifs_Pri >> math && ifs_Pri >> English) {
        Primary_student* pstu=new Primary_student(student_id, name, sex, age, classname, 2, Username, English, math, chinese);
        PSTU.push_back(pstu);//小学生链表增加
        name_num.insert({ name , student_id });//关联学号和姓名
        num_stu.insert({ student_id,pstu });//关联学号和学生基本信息
    }
    ifs_Pri.close();
    std::ifstream ifs_Mid;
    if(!flag) {
        QString save_path = QFileDialog::getOpenFileName(this, "读取中学文件", "", "files(*.txt)");
        ifs_Mid.open(ToString(save_path), std::ios::in | std::ios::binary);
    } else {
        ifs_Mid.open(Mid_File, std::ios::in | std::ios::binary);
    }
    if (!ifs_Mid.is_open()) {// 同
        QMessageBox::critical(this,"警告", "中学生文件不存在!");
        ifs_Mid.close();
        return;
    }
    while (ifs_Mid >> student_id && ifs_Mid >> name && ifs_Mid >> sex && ifs_Mid >> age && ifs_Mid >> classname && ifs_Mid >> Username && ifs_Mid >> chinese && ifs_Mid >> math && ifs_Mid >> English&& ifs_Mid >> geographic && ifs_Mid >> history) {
        Middle_student* mstu = new Middle_student(student_id, name, sex, age, classname, 3, Username, English, math, chinese, geographic, history);
        MSTU.push_back(mstu);//中学生链表增加
        name_num.insert({ name , student_id });//关联学号和姓名
        num_stu.insert({ student_id,mstu });//关联学号和学生基本信息
    }
    ifs_Mid.close();
    std::ifstream ifs_Col;
    if(!flag) {
        QString save_path = QFileDialog::getOpenFileName(this, "读取大学文件", "", "files(*.txt)");
        ifs_Col.open(ToString(save_path), std::ios::in | std::ios::binary);
    } else {
        ifs_Col.open(Col_File, std::ios::in | std::ios::binary);
    }
    if (!ifs_Col.is_open()) {// 同
        QMessageBox::critical(this,"警告", "大学生文件不存在!");
        ifs_Col.close();
        return;
    }
    while (ifs_Col >> student_id && ifs_Col >> name && ifs_Col >> sex && ifs_Col >> age && ifs_Col >> classname && ifs_Col >> Username && ifs_Col >> professional && ifs_Col >> english && ifs_Col >> program_design && ifs_Col >> advance_mathematics) {
        College_student* cstu = new College_student(student_id, name, sex, age, classname, 4, Username, professional, english, program_design, advance_mathematics);
        CSTU.push_back(cstu);//学生链表增加
        name_num.insert({ name , student_id });//关联学号和姓名
        num_stu.insert({ student_id,cstu });//关联学号和学生基本信息
    }
    ifs_Col.close();
    if(!flag) {
        QMessageBox::information(this, "成功", "读取成功！");
    }
}
void Student_Manager::save_id_list() {
    std::ofstream ofs(User_File, std::ios::out | std::ios::binary);//打开账户文件
    for (auto i = ID.begin(); i != ID.end(); ++i) {//迭代器遍历用户链表，保存身份、账号和密码
        ofs << (**i).get_id() << " " << (**i).get_username() << " " << (**i).get_password() << std::endl;
    }
    ofs.close();//关闭文件
}
void Student_Manager::save() {
    std::ofstream ofs(Pri_File, std::ios::out | std::ios::binary);//打开小学生文件
    for (auto i = PSTU.begin(); i != PSTU.end(); ++i) {
        ofs << (**i).get_Student_id() << " " << (**i).get_name() << " " << (**i).get_sex() << " " << (**i).get_age() << " " << (**i).get_classname() <<   " " << (**i).get_username() << " " << (**i).get_Chinese() << " " << (**i).get_Math() << " " << (**i).get_English() << std::endl;
    }
    ofs.close();//关闭小学生文件
    ofs.open(Mid_File, std::ios::out | std::ios::binary);//打开中学生文件
    for (auto i = MSTU.begin(); i != MSTU.end(); ++i) {
        ofs << (**i).get_Student_id() << " " << (**i).get_name() << " " << (**i).get_sex() << " " << (**i).get_age() << " " << (**i).get_classname() << " " << (**i).get_username() << " " << (**i).get_Chinese() << " " << (**i).get_Math() << " " << (**i).get_English() << " " << (**i).get_Geographic() << " " << (**i).get_History() << std::endl;
    }
    ofs.close();//关闭分数文件
    ofs.open(Col_File, std::ios::out | std::ios::binary);//打开大学生文件
    for (auto i = CSTU.begin(); i != CSTU.end(); ++i) {
        ofs << (**i).get_Student_id() << " " << (**i).get_name() << " " << (**i).get_sex() << " " << (**i).get_age() << " " << (**i).get_classname() << " " << (**i).get_username() << " " << (**i).get_Professional() << " " << (**i).get_English() << " " << (**i).get_Program_design() << " " << (**i).get_Advanced_mathematics() << std::endl;
    }
    ofs.close();//关闭分数文件
}
bool Student_Manager::check(int id, std::string username, std::string password){
    if(unm_id.count(username) && unm_id[username] == id){//先进行初步核验，哈希表的查询速度很快
        for(auto i = ID.begin(); i != ID.end(); ++i){//迭代器遍历
            if((*i)->get_username() == username && (*i)->get_password() == password && (*i)->get_id() == id){
                return true;//如果存在相同则返回允许通过
            }
        }
    }
    return false;//否则不能通过
}
std::string Student_Manager::ToString(const QString qStr){
    QByteArray data = qStr.toLocal8Bit();
    return std::string(data);
}

template<typename Type>
bool Student_Manager::Compare_id(Type& A1, Type& A2) {//账户按身份
    return (*A1).get_id() > (*A2).get_id();
}
template<typename Type>
bool Student_Manager::Compare_Username(Type& A1, Type& A2) {//账户按用户名
    return (*A1).get_username() > (*A2).get_username();
}
template<typename Type>
bool Student_Manager::Compare_Ad_math(Type& A1, Type& A2) {//按高等数学
    return (*A1).get_Advanced_mathematics() > (*A2).get_Advanced_mathematics();
}
template<typename Type>
bool Student_Manager::Compare_Chinese(Type& A1, Type& A2) {//按语文
    return (*A1).get_Chinese() > (*A2).get_Chinese();
}
template<typename Type>
bool Student_Manager::Compare_Math(Type& A1, Type& A2) {//按数学
    return (*A1).get_Math() > (*A2).get_Math();
}
template<typename Type>
bool Student_Manager::Compare_English(Type& A1, Type& A2) {//按英语
    return (*A1).get_English() > (*A2).get_English();
}
template<typename Type>
bool Student_Manager::Compare_Geographic(Type& A1, Type& A2) {//按地理
    return (*A1).get_Geographic() > (*A2).get_Geographic();
}
template<typename Type>
bool Student_Manager::Compare_History(Type& A1, Type& A2) {//按历史
    return (*A1).get_History() > (*A2).get_History();
}
template<typename Type>
bool Student_Manager::Compare_Professional(Type& A1, Type& A2) {//按专业
    return (*A1).get_Professional() > (*A2).get_Professional();
}
template<typename Type>
bool Student_Manager::Compare_Program_design(Type& A1, Type& A2) {//按程序设计
    return (*A1).get_Program_design() > (*A2).get_Program_design();
}
template<typename Type>
bool Student_Manager::Compare_Student_id(Type& A1, Type& A2) {//学生按学号
    return (*A1).get_Student_id() > (*A2).get_Student_id();
}
template<typename Type>
bool Student_Manager::Compare_pri_sum(Type& A1, Type& A2) {//按语数英总分
    return (*A1).get_pri_sum() > (*A2).get_pri_sum();//总分高的在前面
}
template<typename Type>
bool Student_Manager::Compare_all_sum(Type& A1, Type& A2) {//按所有科总分
    return (*A1).get_all_sum() > (*A2).get_all_sum();
}
template<typename Type>
bool Student_Manager::Compare_mid_sum(Type& A1, Type& A2) {//按地理历史总分
    return (*A1).get_mid_sum() > (*A2).get_mid_sum();
}
template<typename Type>
bool Student_Manager::Compare_class(Type& A1, Type& A2) {//按班级排
    return (*A1).get_classname() > (*A2).get_classname() || ((*A1).get_classname() == (*A2).get_classname() && (*A1).get_Student_id() > (*A2).get_Student_id());//班级相同则按用户学号
}
template<typename Type>
void Student_Manager::List_Sort(std::list<Type>& List, bool(*compare)(Type &A1, Type &A2)) {//用函数模板接收不同类型的链表，并用函数指针调用不同的比较函数进行排序
    List.sort(compare);
}
void Student_Manager::Sort_Function(int result) {
    if (result == 1) {//按总分排
        List_Sort<Primary_student*>(PSTU, Compare_pri_sum);
        List_Sort<Middle_student*>(MSTU, Compare_all_sum);
        List_Sort<College_student*>(CSTU, Compare_all_sum);
    } else if (result == 2) {//按语数英总分排
        List_Sort<Primary_student*>(PSTU, Compare_pri_sum);
        List_Sort<Middle_student*>(MSTU, Compare_pri_sum);
    } else if (result == 3) {//按地理历史总分排
        List_Sort<Middle_student*>(MSTU, Compare_mid_sum);
    } else if (result == 4) {//按语文成绩排
        List_Sort<Primary_student*>(PSTU, Compare_Chinese);
        List_Sort<Middle_student*>(MSTU, Compare_Chinese);
    } else if (result == 5) {//按数学成绩排
        List_Sort<Primary_student*>(PSTU, Compare_Math);
        List_Sort<Middle_student*>(MSTU, Compare_Math);
    } else if (result == 6) {//按英语成绩排
        List_Sort<Primary_student*>(PSTU, Compare_English);
        List_Sort<Middle_student*>(MSTU, Compare_English);
        List_Sort<College_student*>(CSTU, Compare_English);
    } else if (result == 7) {//按地理成绩排
        List_Sort<Middle_student*>(MSTU, Compare_Geographic);
    } else if (result == 8) {//按历史成绩排
        List_Sort<Middle_student*>(MSTU, Compare_History);
    } else if (result == 9) {//按专业成绩排
        List_Sort<College_student*>(CSTU, Compare_Professional);
    } else if (result == 10) {//按程序设计成绩排
        List_Sort<College_student*>(CSTU, Compare_Program_design);
    }else if (result == 11) {//按高等数学成绩排
        List_Sort<College_student*>(CSTU, Compare_Ad_math);
    } else if (result == 12) {//学生按学号
        List_Sort<Primary_student*>(PSTU, Compare_Student_id);
        List_Sort<Middle_student*>(MSTU, Compare_Student_id);
        List_Sort<College_student*>(CSTU, Compare_Student_id);
    } else if (result == 13) {//账户按班级
        List_Sort<Primary_student*>(PSTU, Compare_class);
        List_Sort<Middle_student*>(MSTU, Compare_class);
        List_Sort<College_student*>(CSTU, Compare_class);
    } else if (result == 14) {//账户按身份
        List_Sort<Account*>(ID, Compare_id);
    } else if(result == 15) {//账户按用户名
        List_Sort<Account*>(ID, Compare_Username);
    }
}

void Student_Manager::remove(std::list<Account*>&ID, std::string name) {
    for (auto i = ID.begin(); i != ID.end(); ++i) {//用迭代器遍历
        if ((*i)->get_username() == name) {//找到位置
            delete (*i);//置空
            *i = NULL;
            ID.erase(i);//后删除
            break;
        }
    }
}
