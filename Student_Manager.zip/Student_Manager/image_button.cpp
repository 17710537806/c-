#include "image_button.h"
#include "ui_image_button.h"

Image_button::Image_button(QWidget *parent) : QWidget(parent), ui(new Ui::Image_button) {
    ui->setupUi(this);

    //设置默认定位
    ui->stackedWidget->setCurrentIndex(0);
    curr_index = 0;

    //关联按键与栈控件联系
    connect(ui->left_btn, &QPushButton::clicked, [=](){
        if(curr_index != 0) {
            ui->stackedWidget->setCurrentIndex(--curr_index);
        }
    });

    connect(ui->right_btn, &QPushButton::clicked, [=](){
        if(curr_index != 1) {
            ui->stackedWidget->setCurrentIndex(++curr_index);
        }
    });
}

Image_button::~Image_button() {
    delete ui;
}

void Image_button::set_image(const QPixmap& fir, const QPixmap& sec) {
    ui->page_1_label->setPixmap(fir);
    ui->page_2_label->setPixmap(sec);

    //设置自动调整图片大小
    ui->page_1_label->setScaledContents(true);
    ui->page_2_label->setScaledContents(true);

    ui->page_1_label->show();
    ui->page_2_label->show();
}
