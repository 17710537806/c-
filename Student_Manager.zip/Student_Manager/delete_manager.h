#ifndef DELETE_MANAGER_H
#define DELETE_MANAGER_H

#include <QWidget>
#include<QPaintEvent>
#include<QPainter>
#include<QMessageBox>
#include<string>
#include<student_manager.h>
namespace Ui {
class Delete_Manager;
}

class Delete_Manager : public QWidget
{
    Q_OBJECT

public:
    explicit Delete_Manager(QWidget *parent = nullptr);
    ~Delete_Manager();

    void init();

signals:
    //设置返回信号
    void choice_return();

private:
    Ui::Delete_Manager *ui;

    //画背景图
    void paintEvent(QPaintEvent *);
};

#endif // DELETE_MANAGER_H
