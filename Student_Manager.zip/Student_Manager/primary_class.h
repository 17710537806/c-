#ifndef PRIMARY_CLASS_H
#define PRIMARY_CLASS_H


class Primary_class {
private://保护数据安全
    int Chinese;//语文成绩
    int Math;//数学成绩
    int English;//英语成绩
    static int Chinese_sum;//语文分数总和
    static int Math_sum;//数学分数总和
    static int English_sum;//英语分数总和
public:
    Primary_class(int english, int math, int chinese);
    ~Primary_class();//消除加入到总分之后的影响
    int get_English();//获取内部成员函数接口
    int get_Math();
    int get_Chinese();
    int get_pri_sum();//求成绩合
    static int get_English_sum();
    static int get_Math_sum();
    static int get_Chinese_sum();
    static int get_All_sum();
};
#endif // PRIMARY_CLASS_H
