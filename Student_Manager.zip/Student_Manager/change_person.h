#ifndef CHANGE_PERSON_H
#define CHANGE_PERSON_H

#include <QWidget>
#include<QMessageBox>
#include<student.h>
#include<primary_student.h>
#include<middle_student.h>
#include<college_student.h>
#include<string>
#include<student_manager.h>
#include<QStringList>
#include<QStandardItem>
#include<unordered_map>
#include<QRegularExpressionValidator>
#include<CustomItemDelegrate.h>
#include<fstream>
#include<QPaintEvent>
#include<QPainter>
#include<change_manager.h>
namespace Ui {
class Change_Person;
}

class Change_Person : public QWidget
{
    Q_OBJECT

public:
    explicit Change_Person(QWidget *parent = nullptr);
    ~Change_Person();

    void init();

    void init_2();

    void search();

    void init_all();

    void init_pri();

    void init_mid();

    void init_col();

    void create_table(bool Pri = true, bool Mid = true, bool Col = true);

    bool check(int end, bool Pri = true, bool Mid = true, bool Col = true);

    bool check_sex(int num);

    bool check_age(int num);

    bool check_psw(int num);

    bool check_id(int num, bool Pri = true, bool Mid = true, bool Col = true);

    bool check_username(int num, bool Pri = true, bool Mid = true, bool Col = true);

    bool check_(int num, int j);

    bool check_score(int num);

signals:
    //设置返回信号
    void choice_return();

private:
    Ui::Change_Person *ui;

    //画背景图
    void paintEvent(QPaintEvent *);

    int curr_index;
};

#endif // CHANGE_PERSON_H
