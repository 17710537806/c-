#ifndef IMAGE_BUTTON_H
#define IMAGE_BUTTON_H

#include <QWidget>
#include<QPushButton>
namespace Ui {
class Image_button;
}

class Image_button : public QWidget
{
    Q_OBJECT

public:
    explicit Image_button(QWidget *parent = nullptr);
    ~Image_button();

    void set_image(const QPixmap& fir, const QPixmap& sec);
private:
    Ui::Image_button *ui;
    int curr_index;
};

#endif // IMAGE_BUTTON_H
