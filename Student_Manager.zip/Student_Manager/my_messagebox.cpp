#include "my_messagebox.h"
#include "ui_my_messagebox.h"

My_messageBox::My_messageBox(QWidget *parent) : QWidget(parent), ui(new Ui::My_messageBox)
{
    ui->setupUi(this);

    //设置图标
    setWindowIcon(QIcon(":/image/School.png"));

    //设置标题
    setWindowTitle("学生成绩管理系统");

    //设置返回
    connect(ui->add_btn, &QPushButton::clicked, [=](){
        if(ui->get_line->text() == "我已明确，并愿意承担相应责任") {
            emit this->choice_return();
            emit this->add();
        } else {
            QMessageBox::critical(this, "错误", "您的输入有误！");
        }
    });


    connect(ui->exit_btn, &QPushButton::clicked, [=](){
        emit this->choice_return();
        emit this->exit();
    });
}

My_messageBox::~My_messageBox()
{
    delete ui;
}

void My_messageBox::paintEvent(QPaintEvent *){
    QPainter painter(this);
    QPixmap pix;
    pix.load(":/image/School.png");
    pix = pix.scaled(pix.width() * 0.1, pix.height() * 0.1);
    painter.drawPixmap(0, 10, pix);
}
