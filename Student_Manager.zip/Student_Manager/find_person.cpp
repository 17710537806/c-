#include "find_person.h"
#include "ui_find_person.h"

Find_Person::Find_Person(QWidget *parent) : QWidget(parent), ui(new Ui::Find_Person) {
    ui->setupUi(this);

    //设置图标
    setWindowIcon(QIcon(":/image/School.png"));

    //设置标题
    setWindowTitle("学生成绩管理系统");

    //设置栈控件图片
    QPixmap Image_0(":/image/init_image.png");
    QPixmap Image_1(":/image/boy_1.png");
    QPixmap Image_2(":/image/boy_2.png");
    QPixmap Image_3(":/image/girl_1.png");
    QPixmap Image_4(":/image/girl_2.png");

    ui->init_image->setPixmap(Image_0);
    ui->init_image->setScaledContents(true);
    ui->init_image->show();

    ui->page_1->set_image(Image_1, Image_2);
    ui->page_2->set_image(Image_3, Image_4);

    //添加下拉内容
    QStringList find_way,find_choice;
    find_choice<<"全部显示"<<"只显示小学生"<<"只显示中学生"<<"只显示大学生"<<"只显示小学和中学生";
    find_way<<"按学号查找"<<"按姓名查找";
    ui->Find_Way->addItems(find_way);

    //初始化
    init();

    //设置label自动换行
    ui->student_id->setWordWrap(true);
    ui->username->setWordWrap(true);
    ui->name->setWordWrap(true);
    ui->classname->setWordWrap(true);
    ui->age->setWordWrap(true);
    ui->sex->setWordWrap(true);

    Find_Manager* fm = new Find_Manager;

    connect(ui->change_btn, &QPushButton::clicked, [=](){
        fm->init();
        fm->show();
    });

    connect(fm, &Find_Manager::choice_return, this, [=](){
        fm->close();
    });

    //链接返回按钮
    connect(ui->exit_button, &QPushButton::clicked, [=]() {
        emit this->choice_return();
    });

    //链接重置按钮
    connect(ui->init_btn, &QPushButton::clicked, [=]() {
        int index = ui->Find_Way->currentIndex();
        if(index == 0) {
            init();
        } else {
            init_table();
        }
    });

    //关联查询按钮
    connect(ui->search_btn, &QPushButton::clicked, [=](){
        if(ui->get_line->text().isEmpty()) {
            QMessageBox::critical(this, "警告", "查找内容不能为空！");
            return;
        }
        int index = ui->Find_Way->currentIndex();
        if(index == 0){
            std::string Student_id = Student_Manager::ToString(ui->get_line->text());
            if (Student_Manager::num_stu.count(Student_id)) {//用学号进行查询，如果哈希表内有该成员，避免使用[]造成不必要的插入
                Student* stu = Student_Manager::num_stu[Student_id];
                ui->student_id->setText(ui->get_line->text());
                ui->username->setText(QString::fromLocal8Bit(stu->get_username()));
                ui->name->setText(QString::fromLocal8Bit(stu->get_name()));
                ui->classname->setText(QString::fromLocal8Bit(stu->get_classname()));
                ui->age->setText(QString::number(stu->get_age()));
                ui->sex->setText(stu->get_sex() == 1?"男" : "女");
                if(stu->get_sex() == 1) {
                    ui->image->setCurrentIndex(1);
                } else {
                    ui->image->setCurrentIndex(0);
                }
                QStandardItemModel *models = new QStandardItemModel;
                if(stu->get_grade() == 4) {
                    models->setItem(0, 0, new QStandardItem("专业"));
                    models->setItem(1, 0, new QStandardItem(QString::number(((College_student*)stu)->get_Professional())));
                    models->setItem(0, 1, new QStandardItem("英语"));
                    models->setItem(1, 1, new QStandardItem(QString::number(((College_student*)stu)->get_English())));
                    models->setItem(0, 2, new QStandardItem("程序设计"));
                    models->setItem(1, 2, new QStandardItem(QString::number(((College_student*)stu)->get_Program_design())));
                    models->setItem(0, 3, new QStandardItem("高等数学"));
                    models->setItem(1, 3, new QStandardItem(QString::number(((College_student*)stu)->get_Advanced_mathematics())));
                } else {
                    models->setItem(0, 0, new QStandardItem("语文"));
                    models->setItem(1, 0, new QStandardItem(QString::number(((Primary_student*)stu)->get_Chinese())));
                    models->setItem(0, 1, new QStandardItem("数学"));
                    models->setItem(1, 1, new QStandardItem(QString::number(((Primary_student*)stu)->get_Math())));
                    models->setItem(0, 2, new QStandardItem("英语"));
                    models->setItem(1, 2, new QStandardItem(QString::number(((Primary_student*)stu)->get_English())));
                    if(stu->get_grade() == 3) {
                        models->setItem(0, 3, new QStandardItem("地理"));
                        models->setItem(1, 3, new QStandardItem(QString::number(((Middle_student*)stu)->get_Geographic())));
                        models->setItem(0, 4, new QStandardItem("历史"));
                        models->setItem(1, 4, new QStandardItem(QString::number(((Middle_student*)stu)->get_History())));
                    }
                }
                ui->tableView->setModel(models);
                Set();
            } else {//哈希表内没有该成员
                QMessageBox::critical(this, "错误", "查询不到该学生！");
            }
        } else {
            check.clear();
            std::string name = Student_Manager::ToString(ui->get_line->text());
            for (auto i = Student_Manager::name_num.begin(); i != Student_Manager::name_num.end(); ++i) {//用迭代器遍历找到姓名相同的成员
                if (i->student_name == name) {
                    check.push_back(i->student_identity);//推入到vector中
                }
            }
            if(check.empty()) {
                QMessageBox::critical(this, "错误", "查询不到该学生！");
            } else {
                int index = ui->find->currentIndex();
                switch(index) {
                    case 0:get_table();break;
                    case 1:get_table(true, false, false);break;
                    case 2:get_table(false, true, false);break;
                    case 3:get_table(false, false, true);break;
                    case 4:get_table(true, true, false);break;
                }
            }
        }
    });

    //关联标签变动
    connect(ui->Find_Way, &QComboBox::currentIndexChanged, this, [=](){
        int index = ui->Find_Way->currentIndex();
        if(index == 0) {
            init();
            ui->stackedWidget->setCurrentIndex(0);
        } else {
            init_table();
            ui->stackedWidget->setCurrentIndex(1);
        }
    });
}

Find_Person::~Find_Person()
{
    delete ui;
}

void Find_Person::get_table(bool Pri, bool Mid, bool Col) {
    QStandardItemModel *models = new QStandardItemModel;
    QStringList headers;
    headers<<"学历"<<"学号"<<"姓名"<<"性别"<<"年龄"<<"班级"<<"用户名"<<"语文"<<"数学"<<"英语"<<"地理"<<"历史"<<"专业"<<"程设"<<"高数"<<"语数英总分"<<"选课总分"<<"所有课总分";
    models->setHorizontalHeaderLabels(headers);
    for(int i = 0, count = 0; i < check.size(); ++i) {
        if(Student_Manager::num_stu.count(check[i])) {
            Student* stu = Student_Manager::num_stu[check[i]];
            switch(stu->get_grade()) {
                case 2:{
                    if(Pri) {
                        models->setItem(count, 0, new QStandardItem("小学生"));
                        models->setItem(count, 1, new QStandardItem(QString::fromLocal8Bit(stu->get_Student_id())));
                        models->setItem(count, 2, new QStandardItem(QString::fromLocal8Bit(stu->get_name())));
                        models->setItem(count, 3, new QStandardItem(stu->get_sex() == 1?"男":"女"));
                        models->setItem(count, 4, new QStandardItem(QString::number(stu->get_age())));
                        models->setItem(count, 5, new QStandardItem(QString::fromLocal8Bit(stu->get_classname())));
                        models->setItem(count, 6, new QStandardItem(QString::fromLocal8Bit(stu->get_username())));
                        models->setItem(count, 7, new QStandardItem(QString::number(((Primary_student*)stu)->get_Chinese())));
                        models->setItem(count, 8, new QStandardItem(QString::number(((Primary_student*)stu)->get_Math())));
                        models->setItem(count, 9, new QStandardItem(QString::number(((Primary_student*)stu)->get_English())));
                        models->setItem(count, 15, new QStandardItem(QString::number(((Primary_student*)stu)->get_pri_sum())));
                        models->setItem(count, 17, new QStandardItem(QString::number(((Primary_student*)stu)->get_pri_sum())));
                        ++count;
                    }
                    break;
                }
                case 3:{
                    if(Mid) {
                        models->setItem(count, 0, new QStandardItem("中学生"));
                        models->setItem(count, 1, new QStandardItem(QString::fromLocal8Bit(stu->get_Student_id())));
                        models->setItem(count, 2, new QStandardItem(QString::fromLocal8Bit(stu->get_name())));
                        models->setItem(count, 3, new QStandardItem(stu->get_sex() == 1?"男":"女"));
                        models->setItem(count, 4, new QStandardItem(QString::number(stu->get_age())));
                        models->setItem(count, 5, new QStandardItem(QString::fromLocal8Bit(stu->get_classname())));
                        models->setItem(count, 6, new QStandardItem(QString::fromLocal8Bit(stu->get_username())));
                        models->setItem(count, 7, new QStandardItem(QString::number(((Middle_student*)stu)->get_Chinese())));
                        models->setItem(count, 8, new QStandardItem(QString::number(((Middle_student*)stu)->get_Math())));
                        models->setItem(count, 9, new QStandardItem(QString::number(((Middle_student*)stu)->get_English())));
                        models->setItem(count, 10, new QStandardItem(QString::number(((Middle_student*)stu)->get_Geographic())));
                        models->setItem(count, 11, new QStandardItem(QString::number(((Middle_student*)stu)->get_History())));
                        models->setItem(count, 15, new QStandardItem(QString::number(((Middle_student*)stu)->get_pri_sum())));
                        models->setItem(count, 16, new QStandardItem(QString::number(((Middle_student*)stu)->get_mid_sum())));
                        models->setItem(count, 17, new QStandardItem(QString::number(((Middle_student*)stu)->get_pri_sum()+((Middle_student*)stu)->get_mid_sum())));
                        ++count;
                    }
                    break;
                }
                case 4:{
                    if(Col) {
                        models->setItem(count, 0, new QStandardItem("大学生"));
                        models->setItem(count, 1, new QStandardItem(QString::fromLocal8Bit(stu->get_Student_id())));
                        models->setItem(count, 2, new QStandardItem(QString::fromLocal8Bit(stu->get_name())));
                        models->setItem(count, 3, new QStandardItem(stu->get_sex() == 1?"男":"女"));
                        models->setItem(count, 4, new QStandardItem(QString::number(stu->get_age())));
                        models->setItem(count, 5, new QStandardItem(QString::fromLocal8Bit(stu->get_classname())));
                        models->setItem(count, 6, new QStandardItem(QString::fromLocal8Bit(stu->get_username())));
                        models->setItem(count, 12, new QStandardItem(QString::number(((College_student*)stu)->get_Professional())));
                        models->setItem(count, 13, new QStandardItem(QString::number(((College_student*)stu)->get_Program_design())));
                        models->setItem(count, 9, new QStandardItem(QString::number(((College_student*)stu)->get_English())));
                        models->setItem(count, 14, new QStandardItem(QString::number(((College_student*)stu)->get_Advanced_mathematics())));
                        models->setItem(count, 17, new QStandardItem(QString::number(((College_student*)stu)->get_all_sum())));
                        ++count;
                    }
                    break;
                }

            }
        }
    }
    ui->name_table->horizontalHeader()->setStretchLastSection(true);
    ui->name_table->verticalHeader()->setStretchLastSection(true);
    ui->name_table->verticalHeader()->setSectionResizeMode(QHeaderView::Stretch);

    //将表单置为只读属性
    ui->name_table->setEditTriggers(QAbstractItemView::NoEditTriggers);

    ui->name_table->setModel(models);
}
void Find_Person::init() {
    //设置初始值
    ui->stackedWidget->setCurrentIndex(0);
    ui->image->setCurrentIndex(2);
    ui->student_id->setText("???");
    ui->username->setText("???");
    ui->name->setText("???");
    ui->classname->setText("???");
    ui->age->setText("???");
    ui->sex->setText("???");
    ui->Find_Way->setCurrentIndex(0);
    QStringList nothing;
    ui->find->addItems(nothing);
    ui->get_line->setText("");
    QStandardItemModel *init_model = new QStandardItemModel;
    init_model->setItem(1, 4, new QStandardItem(""));
    ui->tableView->setModel(init_model);
    Set();

    ui->find->clear();
}

void Find_Person::Set() {
    //设置填充和分布均匀
    ui->tableView->horizontalHeader()->setStretchLastSection(true);
    ui->tableView->horizontalHeader()->setSectionResizeMode(QHeaderView::Stretch);
    ui->tableView->verticalHeader()->setStretchLastSection(true);
    ui->tableView->verticalHeader()->setSectionResizeMode(QHeaderView::Stretch);

    //将表单置为只读属性
    ui->tableView->setEditTriggers(QAbstractItemView::NoEditTriggers);
}

void Find_Person::init_table() {
    ui->find->clear();
    ui->get_line->setText("");
    QStringList finding;
    finding << "全部显示" << "只显示小学生"<<"只显示中学生"<<"只显示大学生"<<"只显示小学和中学生";
    ui->find->addItems(finding);

    QStringList headers;
    QStandardItemModel *models = new QStandardItemModel();
    headers<<"学历"<<"学号"<<"姓名"<<"性别"<<"年龄"<<"班级"<<"用户名"<<"语文"<<"数学"<<"英语"<<"地理"<<"历史"<<"专业"<<"程设"<<"高数"<<"语数英总分"<<"选课总分"<<"所有课总分";
    models->setHorizontalHeaderLabels(headers);

    ui->name_table->horizontalHeader()->setSectionResizeMode(QHeaderView::ResizeToContents);
    ui->name_table->setModel(models);

    //将表单置为只读属性
    ui->name_table->setEditTriggers(QAbstractItemView::NoEditTriggers);

    models->setItem(10, 17, new QStandardItem(""));
}

void Find_Person::paintEvent(QPaintEvent *){
    QPainter painter(this);
    QPixmap pix;
    pix.load(":/image/School.png");
    pix = pix.scaled(pix.width() * 0.2, pix.height() * 0.2);
    painter.drawPixmap(0, 10, pix);
}
