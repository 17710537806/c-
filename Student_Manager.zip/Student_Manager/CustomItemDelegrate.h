#ifndef CUSTOMITEMDELEGRATE_H
#define CUSTOMITEMDELEGRATE_H

#include <QWidget>
#include <QStyledItemDelegate>
#include <QLineEdit>
#include<QRegularExpressionValidator>

class CustomItemDelegrate : public QStyledItemDelegate
{
    Q_OBJECT
public:
    CustomItemDelegrate(const QRegularExpression& regExp, QObject* parent = nullptr);

    QWidget *createEditor(QWidget* parent, const QStyleOptionViewItem& option, const QModelIndex& index ) const;
    void setEditorData(QWidget* editor, const QModelIndex& index ) const;
    void setModelData(QWidget* editor, QAbstractItemModel* model, const QModelIndex& index ) const;

private:
    QRegularExpression m_regExp;
};

#endif // CUSTOMITEMDELEGRATE_H
