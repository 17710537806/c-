#include "middle_class.h"
Middle_class::Middle_class(int geographic, int history) {
    Geographic = geographic, History = history;
    Geographic_sum += geographic, History_sum += history;
}
Middle_class::~Middle_class() {
    Geographic_sum -= Geographic, History_sum -= History;
}
int Middle_class::get_Geographic() {
    return Geographic;
}
int Middle_class::get_History() {
    return History;
}
int Middle_class::get_mid_sum() {
    return Geographic + History;
}
int Middle_class::Geographic_sum = 0;
int Middle_class::History_sum = 0;
int Middle_class::get_Geographic_sum() {
    return Geographic_sum;
}
int Middle_class::get_History_sum() {
    return History_sum;
}
int Middle_class::get_All_sum() {
    return Geographic_sum + History_sum;
}
