#ifndef CHANGE_MANAGER_H
#define CHANGE_MANAGER_H

#include <QWidget>
#include<QRegularExpressionValidator>
#include<QMessageBox>
#include<string>
#include<student_manager.h>
namespace Ui {
class Change_Manager;
}

class Change_Manager : public QWidget
{
    Q_OBJECT

public:
    explicit Change_Manager(QWidget *parent = nullptr);
    ~Change_Manager();

signals:
    //设置返回信号
    void choice_return();

private:
    //画背景图
    void paintEvent(QPaintEvent *);

    Ui::Change_Manager *ui;
};

#endif // CHANGE_MANAGER_H
