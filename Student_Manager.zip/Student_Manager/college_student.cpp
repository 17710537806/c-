#include "college_student.h"
College_student::College_student(std::string student_id, std::string Name, int Sex, int Age, std::string Classname, int Grade, std::string Username, int professional, int english, int program_design, int advanced_mathematics)
: Student(student_id, Name, Sex, Age, Classname, Grade, Username), College_class(professional, english, program_design, advanced_mathematics) {}

