#ifndef SORT_AND_CHECK_H
#define SORT_AND_CHECK_H

#include <QWidget>
#include<QStringList>
#include<QStandardItem>
#include<student_manager.h>
#include<primary_student.h>
#include<middle_student.h>
#include<college_student.h>
#include<QFileDialog>
#include<QMessageBox>
#include<QFile>
#include<QDir>
#include<QPaintEvent>
#include<QPainter>
namespace Ui {
class sort_and_check;
}

class sort_and_check : public QWidget
{
    Q_OBJECT

public:
    explicit sort_and_check(QWidget *parent = nullptr);
    ~sort_and_check();

    void create_table(bool Pri = true, bool Mid = true , bool Col = true, bool reverse = false);

    void create_IDtable(bool Pri = true, bool Mid = true , bool Col = true);

    void statistics();

    void init();

    void save();

signals:
    //设置返回信号
    void choice_return();

private:
    Ui::sort_and_check *ui;

    //画背景图
    void paintEvent(QPaintEvent *);
};

#endif // SORT_AND_CHECK_H
