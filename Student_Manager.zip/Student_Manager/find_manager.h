#ifndef FIND_MANAGER_H
#define FIND_MANAGER_H

#include <QWidget>
#include<QPushButton>
#include<QMessageBox>
#include<string>
#include<student_manager.h>
#include<QPaintEvent>
#include<QPainter>
namespace Ui {
class Find_Manager;
}

class Find_Manager : public QWidget
{
    Q_OBJECT

public:
    explicit Find_Manager(QWidget *parent = nullptr);
    ~Find_Manager();

    void init();
signals:
    //设置返回信号
    void choice_return();

private:
    Ui::Find_Manager *ui;

    //画背景图
    void paintEvent(QPaintEvent *);
};

#endif // FIND_MANAGER_H
