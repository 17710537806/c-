#ifndef ACCOUNT_H
#define ACCOUNT_H
#include<string>

class Account
{
private://保护数据安全
    int id;//身份
    std::string username;//账号
    std::string password;//密码
public:
    Account(std::string Username, std::string psw,int Id);//有参构造
    int get_id();
    std::string get_username();
    std::string get_password();
};

#endif // ACCOUNT_H
