#ifndef ADD_MANAGER_H
#define ADD_MANAGER_H

#include <QWidget>
#include<QPaintEvent>
#include<QPainter>
#include<QRegularExpressionValidator>
#include<string>
#include<student_manager.h>
#include<QMessageBox>
namespace Ui {
class Add_Manager;
}

class Add_Manager : public QWidget
{
    Q_OBJECT

public:
    explicit Add_Manager(QWidget *parent = nullptr);
    ~Add_Manager();

    void init();

private:
    Ui::Add_Manager *ui;

    //画背景图
    void paintEvent(QPaintEvent *);

signals:
    //设置返回信号
    void choice_return();
};

#endif // ADD_MANAGER_H
