#include "delete_person.h"
#include "ui_delete_person.h"

Delete_Person::Delete_Person(QWidget *parent) : QWidget(parent), ui(new Ui::Delete_Person) {
    ui->setupUi(this);

    //设置图标
    setWindowIcon(QIcon(":/image/School.png"));

    //设置标题
    setWindowTitle("学生成绩管理系统");

    //设置图片
    QPixmap Image_0(":/image/init_image.png");
    QPixmap Image_1(":/image/boy_1.png");
    QPixmap Image_2(":/image/boy_2.png");
    QPixmap Image_3(":/image/girl_1.png");
    QPixmap Image_4(":/image/girl_2.png");

    ui->page_one_2->setPixmap(Image_0);
    ui->page_one_2->setScaledContents(true);
    ui->page_one_2->show();

    ui->page_one->set_image(Image_1, Image_2);
    ui->page_two->set_image(Image_3, Image_4);


    //设置label自动换行
    ui->student_id_2->setWordWrap(true);
    ui->username_2->setWordWrap(true);
    ui->name_2->setWordWrap(true);
    ui->classname_2->setWordWrap(true);
    ui->age_2->setWordWrap(true);
    ui->sex_2->setWordWrap(true);

    init();

    //关联重置值
    connect(ui->init_btn_2, &QPushButton::clicked, [=]() {
        init();
    });

    //关联返回键
    connect(ui->exit_button, &QPushButton::clicked, [=]() {
        emit this->choice_return();
    });

    //关联查找键
    connect(ui->check_btn, &QPushButton::clicked, [=](){
        if(ui->Get_line->text().isEmpty()) {
            QMessageBox::critical(this, "警告", "查找内容不能为空！");
            return;
        }
        std::string Student_id = Student_Manager::ToString(ui->Get_line->text());
        if (Student_Manager::num_stu.count(Student_id)) {//用学号进行查询，如果哈希表内有该成员，避免使用[]造成不必要的插入
            Student* stu = Student_Manager::num_stu[Student_id];
            ui->student_id_2->setText(ui->Get_line->text());
            ui->username_2->setText(QString::fromLocal8Bit(stu->get_username()));
            ui->name_2->setText(QString::fromLocal8Bit(stu->get_name()));
            ui->classname_2->setText(QString::fromLocal8Bit(stu->get_classname()));
            ui->age_2->setText(QString::number(stu->get_age()));
            ui->sex_2->setText(stu->get_sex() == 1?"男" : "女");
            if(stu->get_sex() == 1) {
                ui->Image->setCurrentIndex(0);
            } else {
                ui->Image->setCurrentIndex(2);
            }
            QStandardItemModel *models = new QStandardItemModel;
            if(stu->get_grade() == 4) {
                models->setItem(0, 0, new QStandardItem("专业"));
                models->setItem(1, 0, new QStandardItem(QString::number(((College_student*)stu)->get_Professional())));
                models->setItem(0, 1, new QStandardItem("英语"));
                models->setItem(1, 1, new QStandardItem(QString::number(((College_student*)stu)->get_English())));
                models->setItem(0, 2, new QStandardItem("程序设计"));
                models->setItem(1, 2, new QStandardItem(QString::number(((College_student*)stu)->get_Program_design())));
                models->setItem(0, 3, new QStandardItem("高等数学"));
                models->setItem(1, 3, new QStandardItem(QString::number(((College_student*)stu)->get_Advanced_mathematics())));
            } else {
                models->setItem(0, 0, new QStandardItem("语文"));
                models->setItem(1, 0, new QStandardItem(QString::number(((Primary_student*)stu)->get_Chinese())));
                models->setItem(0, 1, new QStandardItem("数学"));
                models->setItem(1, 1, new QStandardItem(QString::number(((Primary_student*)stu)->get_Math())));
                models->setItem(0, 2, new QStandardItem("英语"));
                models->setItem(1, 2, new QStandardItem(QString::number(((Primary_student*)stu)->get_English())));
                if(stu->get_grade() == 3) {
                    models->setItem(0, 3, new QStandardItem("地理"));
                    models->setItem(1, 3, new QStandardItem(QString::number(((Middle_student*)stu)->get_Geographic())));
                    models->setItem(0, 4, new QStandardItem("历史"));
                    models->setItem(1, 4, new QStandardItem(QString::number(((Middle_student*)stu)->get_History())));
                }
            }
            ui->tableView_2->setModel(models);
            Set();
        } else {//哈希表内没有该成员
            QMessageBox::critical(this, "错误", "查询不到该学生！");
        }
    });

    My_messageBox* mm = new My_messageBox;
    //关联清空键
    connect(ui->destroy_btn, &QPushButton::clicked, [=](){
        //能使用这个选项的只有老师
        int ret = QMessageBox::question(this, "选择", "您是否要清空链表？(注意:该过程无法恢复）", QMessageBox::Yes, QMessageBox::No);
        if(ret == QMessageBox::No) {
            QMessageBox::information(this, "提示", "已取消清空！");
            return;
        }
        mm->show();
    });

    connect(mm, &My_messageBox::choice_return, this, [=](){
        mm->close();
    });

    connect(mm, &My_messageBox::add, this, [=]() {
        Account* Me = new Account(Student_Manager::Username, Student_Manager::Password, 1);
        Student_Manager::Clear_All_List();
        Student_Manager::PSTU.clear(), Student_Manager::MSTU.clear(), Student_Manager::CSTU.clear(), Student_Manager::ID.clear(), Student_Manager::name_num.clear(), Student_Manager::num_stu.clear(), Student_Manager::unm_id.clear();
        Student_Manager::ID.push_back(Me);
        Student_Manager::unm_id.insert({ Me->get_username(), 1});//标记该用户名使用者为老师*/
        QMessageBox::information(this, "提示", "已清空系统内所有信息！");
    });

    connect(mm, &My_messageBox::exit, this, [=](){
        QMessageBox::information(this, "提示", "已取消清空！");
    });

    //关联删除键
    connect(ui->delete_btn, &QPushButton::clicked, [=](){
        if(ui->Get_line->text().isEmpty()) {
            QMessageBox::critical(this, "警告", "查找内容不能为空！");
            return;
        }
        std::string Student_id = Student_Manager::ToString(ui->Get_line->text());
        if (Student_Manager::num_stu.count(Student_id)) {//查找
            Student* stu = Student_Manager::num_stu[Student_id];
            int ret = QMessageBox::question(this, "选择", "请确保已经对该学生信息进行过核实<br>是否删除该学生", QMessageBox::Yes, QMessageBox::No);
            if(ret == QMessageBox::No) {
                QMessageBox::information(this, "提示", "已取消删除！");
                return;
            }
            Student_Manager::remove(Student_Manager::ID, stu->get_username());//清除账号
            for (auto i = Student_Manager::name_num.begin(); i != Student_Manager::name_num.end(); ++i) {//消除各个关联容器影响
                if ((*i).student_identity == stu->get_Student_id() && (*i).student_name == stu->get_name()) {
                    Student_Manager::name_num.erase(i);
                    break;
                }
            }
            Student_Manager::num_stu.erase(stu->get_Student_id());
            Student_Manager::unm_id.erase(stu->get_username());
            if (stu->get_grade() == 2) {//删除链表内
                Student_Manager::PSTU.remove((Primary_student*)stu);
                delete (Primary_student*)stu;//置空，强转保证调用析构函数
            } else if (stu->get_grade() == 3) {
                Student_Manager::MSTU.remove((Middle_student*)stu);
                delete (Middle_student*)stu;//置空，强转保证调用析构函数
            } else {
                Student_Manager::CSTU.remove((College_student*)stu);
                delete (College_student*)stu;//置空，强转保证调用析构函数
            }
            stu = NULL;
            QMessageBox::information(this, "删除学生成功", "删除学生成功！");
            init();
        } else {
            QMessageBox::critical(this, "错误", "查询不到该学生！");
        }
    });

    Delete_Manager* dm = new Delete_Manager;
    //关联删除管理者键
    connect(ui->delete_manager, &QPushButton::clicked, [=](){
        dm->init();
        dm->show();
    });

    //监听返回
    connect(dm, &Delete_Manager::choice_return, this, [=](){
        dm->close();
    });
}

Delete_Person::~Delete_Person() {
    delete ui;
}

void Delete_Person::init() {
    ui->Image->setCurrentIndex(1);
    ui->student_id_2->setText("???");
    ui->username_2->setText("???");
    ui->name_2->setText("???");
    ui->classname_2->setText("???");
    ui->age_2->setText("???");
    ui->sex_2->setText("???");
    ui->Get_line->setText("");
    QStandardItemModel *init_model = new QStandardItemModel;
    init_model->setItem(1, 4, new QStandardItem(""));
    ui->tableView_2->setModel(init_model);
    Set();
}

void Delete_Person::Set() {
    //设置填充和分布均匀
    ui->tableView_2->horizontalHeader()->setStretchLastSection(true);
    ui->tableView_2->horizontalHeader()->setSectionResizeMode(QHeaderView::Stretch);
    ui->tableView_2->verticalHeader()->setStretchLastSection(true);
    ui->tableView_2->verticalHeader()->setSectionResizeMode(QHeaderView::Stretch);

    //将表单置为只读属性
    ui->tableView_2->setEditTriggers(QAbstractItemView::NoEditTriggers);
}

void Delete_Person::paintEvent(QPaintEvent *){
    QPainter painter(this);
    QPixmap pix;
    pix.load(":/image/School.png");
    pix = pix.scaled(pix.width() * 0.2, pix.height() * 0.2);
    painter.drawPixmap(0, 10, pix);
}
