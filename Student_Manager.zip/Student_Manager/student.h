#ifndef STUDENT_H
#define STUDENT_H

#include<string>

class Student{//继承身份类
private://保护数据安全
    std::string Student_id;//学生学号
    std::string name;//学生姓名
    int sex;//学生性别
    int age;//年龄
    std::string classname;//班级
    int grade;//年级
    std::string username;//学生的账户名称
public:
    Student(std::string Username);//用作出示菜单时，同时记录当前用户用户名
    Student(std::string student_id, std::string Name, int Sex, int Age, std::string Classname, int Grade, std::string Username);
    std::string get_Student_id();//获取内部成员函数接口
    std::string get_name();
    int get_sex();
    int get_age();
    std::string get_classname();
    int get_grade();
    std::string get_username();
};
#endif // STUDENT_H
