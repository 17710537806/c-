#include "student_manager.h"
#include <QApplication>
int main(int argc, char *argv[]){
    QApplication a(argc, argv);
    Student_Manager w;
    w.show();
    return a.exec();
}
