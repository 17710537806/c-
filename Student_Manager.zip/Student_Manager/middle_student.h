#ifndef MIDDLE_STUDENT_H
#define MIDDLE_STUDENT_H
#include<primary_student.h>
#include<middle_class.h>
#include<string>
class Middle_student :public Primary_student, public Middle_class {//多继承中学课程和小学课程
private:
    static int Chinese_sum;//单独记录语数英的总成绩，因为构造函数会把中学和小学的语数英成绩全部统计在一起
    static int Math_sum;
    static int English_sum;
public://下行为有参构造
    Middle_student(std::string student_id, std::string Name, int Sex, int Age, std::string Classname, int Grade, std::string Username, int english, int math, int chinese, int geographic, int history);
    ~Middle_student();//消除加入到总分之后的影响
    int get_all_sum();//求五科成绩和
    static int get_Chinese_sum();
    static int get_Math_sum();
    static int get_English_sum();
    static int get_All_sum();
};

#endif // MIDDLE_STUDENT_H
