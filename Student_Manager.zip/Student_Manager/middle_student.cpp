#include "middle_student.h"
Middle_student::Middle_student(std::string student_id, std::string Name, int Sex, int Age, std::string Classname, int Grade, std::string Username, int english, int math, int chinese, int geographic, int history)
: Primary_student(student_id, Name, Sex, Age, Classname, Grade, Username, english, math, chinese), Middle_class(geographic, history){
    Chinese_sum += chinese, Math_sum += math, English_sum += english;
}
Middle_student::~Middle_student() {
    Chinese_sum -= get_Chinese(), Math_sum -= get_Math(), English_sum -= get_English();
}
int Middle_student::get_all_sum() {
    return get_pri_sum() + get_mid_sum();
}
int Middle_student::Chinese_sum = 0;
int Middle_student::Math_sum = 0;
int Middle_student::English_sum = 0;
int Middle_student::get_Chinese_sum() {
    return Chinese_sum;
}
int Middle_student::get_Math_sum() {
    return Math_sum;
}
int Middle_student::get_English_sum() {
    return English_sum;
}
int Middle_student::get_All_sum() {
    return Chinese_sum + Math_sum + English_sum;
}
