#include "change_person.h"
#include "ui_change_person.h"

Change_Person::Change_Person(QWidget *parent) : QWidget(parent), ui(new Ui::Change_Person) {
    ui->setupUi(this);

    //设置图标
    setWindowIcon(QIcon(":/image/School.png"));

    //设置标题
    setWindowTitle("学生成绩管理系统");

    //设置栈控件图片
    QPixmap Image_1(":/image/boy_1.png");
    QPixmap Image_2(":/image/boy_2.png");
    QPixmap Image_3(":/image/girl_1.png");
    QPixmap Image_4(":/image/girl_2.png");
    ui->page_1->set_image(Image_1, Image_2);
    ui->page_3->set_image(Image_3, Image_4);

    //利用正则表达式控制输入
    ui->password_line->setValidator(new QRegularExpressionValidator(QRegularExpression("[a-zA-Z0-9]+$")));
    ui->password_check->setValidator(new QRegularExpressionValidator(QRegularExpression("[a-zA-Z0-9]+$")));

    ui->Pri_chinese->setValidator(new QIntValidator(0, 100, this));
    ui->Pri_math->setValidator(new QIntValidator(0, 100, this));
    ui->Pri_english->setValidator(new QIntValidator(0, 100, this));

    ui->Mid_chinese->setValidator(new QIntValidator(0, 100, this));
    ui->Mid_math->setValidator(new QIntValidator(0, 100, this));
    ui->Mid_english->setValidator(new QIntValidator(0, 100, this));
    ui->Mid_geographic->setValidator(new QIntValidator(0, 100, this));
    ui->Mid_history->setValidator(new QIntValidator(0, 100, this));

    ui->Col_professional->setValidator(new QIntValidator(0, 100, this));
    ui->Col_english->setValidator(new QIntValidator(0, 100, this));
    ui->Col_program_design->setValidator(new QIntValidator(0, 100, this));
    ui->Col_Ad_math->setValidator(new QIntValidator(0, 100, this));

    //设置下拉内容
    QStringList age;
    for(int i = 8; i <= 25; ++i) {
        age.append(QString::number(i));
    }
    ui->age->addItems(age);

    QStringList screen;
    screen<<"全部显示"<<"只显示小学生"<<"只显示中学生"<<"只显示大学生";
    ui->screen->addItems(screen);

    QStringList find_way;
    find_way<<"按学号查找"<<"按姓名查找";
    ui->find_way->addItems(find_way);

    //设置最多位数
    ui->password_line->setMaxLength(15);
    ui->password_check->setMaxLength(15);

    init();

    Change_Manager* cm = new Change_Manager;

    connect(ui->psw_btn, &QPushButton::clicked, [=](){
        cm->show();
    });

    connect(cm, &Change_Manager::choice_return, this, [=](){
        cm->close();
    });

    //关联左右按键
    connect(ui->left_btn, &QPushButton::clicked, [=](){
        if(curr_index != 0) {
            init();
            ui->view->setCurrentIndex(--curr_index);
        }
    });

    connect(ui->right_btn, &QPushButton::clicked, [=](){
        if(curr_index != 1) {
            init_2();
            ui->view->setCurrentIndex(++curr_index);
        }
    });

    //关联修改键
    connect(ui->change_btn, &QPushButton::clicked, [=](){
        //进行一系列合法确认
        if(ui->get_line->text().isEmpty()) {
            QMessageBox::critical(this, "警告", "查找内容不能为空！");
            return;
        }
        std::string Student_id = Student_Manager::ToString(ui->get_line->text());
        if (!Student_Manager::num_stu.count(Student_id)) {
            QMessageBox::critical(this, "警告", "查无此人！");
            return;
        }
        std::string Username = Student_Manager::ToString(ui->username_line->text());
        if(Student_Manager::unm_id.count(Username) && Username != Student_Manager::num_stu[Student_id]->get_username()) {
            QMessageBox::critical(this, "错误", "该用户名已被使用！");
            return;
        }
        std::string student_id = Student_Manager::ToString(ui->id_line->text());
        if(Student_Manager::num_stu.count(student_id) && student_id != Student_id) {
            QMessageBox::critical(this, "错误", "该学号已被使用！");
            return;
        }
        std::string fir_psw = Student_Manager::ToString(ui->password_line->text());
        std::string sec_psw = Student_Manager::ToString(ui->password_check->text());
        if(fir_psw != sec_psw) {
            QMessageBox::critical(this, "错误", "两次密码输入不一致！");
            return;
        }
        if(fir_psw.length() < 8) {
            QMessageBox::critical(this, "错误", "密码长度需在8-15之间！");
            return;
        }
        int grade = ui->tabWidget->currentIndex() + 2;
        std::string name = Student_Manager::ToString(ui->name_line->text());
        std::string classname = Student_Manager::ToString(ui->classname_line->text());
        int sex;
        int age = ui->age->currentIndex() + 8;
        if(this->ui->boy_btn->isChecked()) {
            sex = 1;
        } else {
            sex = 2;
        }
        if(name.empty()) {
            QMessageBox::critical(this, "错误", "姓名不能为空！");
            return;
        }
        if(Username.empty()) {
            QMessageBox::critical(this, "错误", "用户名不能为空！");
            return;
        }
        if(student_id.empty()) {
            QMessageBox::critical(this, "错误", "学号不能为空！");
            return;
        }
        if(classname.empty()) {
            QMessageBox::critical(this, "错误", "班级不能为空！");
            return;
        }
        if(grade == 2) {
            if(ui->Pri_english->text().isEmpty()) {
                QMessageBox::critical(this, "错误", "英语成绩不能为空！");
                return;
            }
            if(ui->Pri_math->text().isEmpty()) {
                QMessageBox::critical(this, "错误", "数学成绩不能为空！");
                return;
            }
            if(ui->Pri_chinese->text().isEmpty()) {
                QMessageBox::critical(this, "错误", "语文成绩不能为空！");
                return;
            }
        } else if(grade == 3) {
            if(ui->Mid_english->text().isEmpty()) {
                QMessageBox::critical(this, "错误", "英语成绩不能为空！");
                return;
            }
            if(ui->Mid_math->text().isEmpty()) {
                QMessageBox::critical(this, "错误", "数学成绩不能为空！");
                return;
            }
            if(ui->Mid_chinese->text().isEmpty()) {
                QMessageBox::critical(this, "错误", "语文成绩不能为空！");
                return;
            }
            if(ui->Mid_geographic->text().isEmpty()) {
                QMessageBox::critical(this, "错误", "地理成绩不能为空！");
                return;
            }
            if(ui->Mid_history->text().isEmpty()) {
                QMessageBox::critical(this, "错误", "历史成绩不能为空！");
                return;
            }
        } else {
            if(ui->Col_professional->text().isEmpty()) {
                QMessageBox::critical(this, "错误", "专业成绩不能为空！");
                return;
            }
            if(ui->Col_english->text().isEmpty()) {
                QMessageBox::critical(this, "错误", "英语成绩不能为空！");
                return;
            }
            if(ui->Col_program_design->text().isEmpty()) {
                QMessageBox::critical(this, "错误", "程序设计成绩不能为空！");
                return;
            }
            if(ui->Col_Ad_math->text().isEmpty()) {
                QMessageBox::critical(this, "错误", "高等数学成绩不能为空！");
                return;
            }
        }
        //删除内容
        int ret = QMessageBox::question(this, "选择", "请确认是否修改当前学生?", QMessageBox::Yes, QMessageBox::No);
        if(ret == QMessageBox::No) {
            QMessageBox::information(this, "提示", "已取消修改！");
            return;
        }
        Student* stu = Student_Manager::num_stu[Student_id];
        Student_Manager::remove(Student_Manager::ID, stu->get_username());//清除账号
        for (auto i = Student_Manager::name_num.begin(); i != Student_Manager::name_num.end(); ++i) {//消除各个关联容器影响
            if ((*i).student_identity == stu->get_Student_id() && (*i).student_name == stu->get_name()) {
                Student_Manager::name_num.erase(i);
                break;
            }
        }
        Student_Manager::num_stu.erase(stu->get_Student_id());
        Student_Manager::unm_id.erase(stu->get_username());
        if (stu->get_grade() == 2) {//删除链表内
            Student_Manager::PSTU.remove((Primary_student*)stu);
            delete (Primary_student*)stu;//置空，强转保证调用析构函数
        }
        else if (stu->get_grade() == 3) {
            Student_Manager::MSTU.remove((Middle_student*)stu);
            delete (Middle_student*)stu;//置空，强转保证调用析构函数
        }
        else {
            Student_Manager::CSTU.remove((College_student*)stu);
            delete (College_student*)stu;//置空，强转保证调用析构函数
        }
        stu = NULL;
        //添加内容
        Account* Person = new Account(Username, fir_psw, grade);//创建对应身份的学生账户，并推入到账户链表中
        if (Person) {//如果成功分配了内存
            Student_Manager::ID.push_back(Person);
            Student_Manager::unm_id.insert({Username, grade});//标记对应的学生类型
        } else {//内存分配失败，则提示用户，并结束函数，不执行以后的函数功能
            QMessageBox::critical(this, "警告", "内存不足,创建失败！");
            return;
        }
        if(grade == 2) {
            int english = ui->Pri_english->text().toInt();
            int math = ui->Pri_math->text().toInt();
            int chinese = ui->Pri_chinese->text().toInt();
            Primary_student*stu = new Primary_student(student_id, name, sex, age, classname, grade, Username, english, math, chinese);
            if (!stu) {//内存不足
                QMessageBox::critical(this, "警告", "内存不足,创建失败！对应学生账户也将会销毁！");
                Student_Manager::unm_id.erase(Username);//删除该学生账户账号对应的记录
                delete Person;//删除账户
                Person = NULL;//置空
                return;
            } else {
                QMessageBox::information(this, "修改学生成功", "修改学生成功!");
                Student_Manager::PSTU.push_back(stu);//加入到学生链表里面
                Student_Manager::num_stu.insert({ student_id, stu });//关联学生学号和对应学生信息
            }
        } else if(grade == 3) {
            int english = ui->Mid_english->text().toInt();
            int math = ui->Mid_math->text().toInt();
            int chinese = ui->Mid_chinese->text().toInt();
            int geographic = ui->Mid_geographic->text().toInt();
            int history = ui->Mid_history->text().toInt();
            Middle_student*stu = new Middle_student(student_id, name, sex, age, classname, grade, Username, english, math, chinese, geographic, history);
            if (!stu) {//内存不足
                QMessageBox::critical(this, "警告", "内存不足,创建失败！对应学生账户也将会销毁！");
                Student_Manager::unm_id.erase(Username);//删除该学生账户账号对应的记录
                delete Person;//删除账户
                Person = NULL;//置空
                return;
            } else {
                QMessageBox::information(this, "修改学生成功", "修改学生成功!");
                Student_Manager::MSTU.push_back(stu);//加入到学生链表里面
                Student_Manager::num_stu.insert({ student_id, stu });//关联学生学号和对应学生信息
            }
        } else{
            int professional = ui->Col_professional->text().toInt();
            int english = ui->Col_english->text().toInt();
            int program_design = ui->Col_program_design->text().toInt();
            int advance_mathematics = ui->Col_Ad_math->text().toInt();
            College_student* stu= new College_student(student_id, name, sex, age, classname, grade, Username, professional, english, program_design, advance_mathematics);
            if (!stu) {//内存不足
                QMessageBox::critical(this, "警告", "内存不足,创建失败！对应学生账户也将会销毁！");
                Student_Manager::unm_id.erase(Username);//删除该学生账户账号对应的记录
                delete Person;//删除账户
                Person = NULL;//置空
                return;
            } else {
                QMessageBox::information(this, "修改学生成功", "修改学生成功!");
                Student_Manager::CSTU.push_back(stu);//加入到学生链表里面
                Student_Manager::num_stu.insert({ student_id, stu });//关联学生学号和对应学生信息
            }
        }
    });

    //关联返回键
    connect(ui->exit_btn, &QPushButton::clicked, this, [=](){
        emit this->choice_return();
    });

    connect(ui->exit_btn_2, &QPushButton::clicked, this, [=](){
        emit this->choice_return();
    });

    //关联重置键
    connect(ui->init_btn, &QPushButton::clicked, this, [=](){
        init();
    });

    connect(ui->init_btn_2, &QPushButton::clicked, this, [=](){
        init_2();
    });

    //关联性别控件
    connect(ui->boy_btn, &QRadioButton::clicked, this, [=](){
        ui->stackedWidget->setCurrentIndex(0);
    });

    connect(ui->girl_btn, &QRadioButton::clicked, this, [=](){
        ui->stackedWidget->setCurrentIndex(1);
    });

    //关联还原键
    connect(ui->clear_btn, &QPushButton::clicked, this, [=](){
        search();
    });

    //关联查找键
    connect(ui->search_btn, &QPushButton::clicked, this, [=](){
        search();
    });

    //关联还原键
    connect(ui->re_btn, &QPushButton::clicked, this, [=](){
        int index = ui->screen->currentIndex();
        switch(index) {
            case 0:init_all();break;
            case 1:init_pri();break;
            case 2:init_mid();break;
            case 3:init_col();break;
        }
    });

    //关联筛查键
    connect(ui->screen, &QComboBox::currentIndexChanged, this, [=](){
        int index = ui->screen->currentIndex();
        switch(index) {
            case 0:init_all();break;
            case 1:init_pri();break;
            case 2:init_mid();break;
            case 3:init_col();break;
        }
    });

    connect(ui->check_btn, &QPushButton::clicked, this, [=]{
        int index = ui->find_way->currentIndex();
        int end = ui->list_table->model()->rowCount();
        if(index == 0) {
            for(int i = 0; i < end; ++i) {
                if(ui->check_line->text() == ui->list_table->model()->data(ui->list_table->model()->index(i, 1)).toString()) {
                    ui->list_table->selectRow(i);
                }
            }
        } else {
            for(int i = 0; i < end; ++i) {
                if(ui->check_line->text() == ui->list_table->model()->data(ui->list_table->model()->index(i, 2)).toString()) {
                    ui->list_table->selectRow(i);
                }
            }
        }
    });

    //监听返回
    connect(ui->list_table, &mytableview::add, this, [=](){
        ui->list_table->model()->insertRow(mytableview::CurRow);
    });

    connect(ui->list_table, &mytableview::remove, this, [=](){
        ui->list_table->model()->removeRow(mytableview::CurRow);
    });

    //设置多选
    ui->list_table->setSelectionMode(QAbstractItemView::SelectionMode::MultiSelection);

    //关联修改键
    connect(ui->fix_btn, &QPushButton::clicked, this, [=](){
        int index = ui->screen->currentIndex();
        bool flag = false;
        int end = ui->list_table->model()->rowCount();
        switch(index) {
            case 0:{flag = check(end);if(!flag) {QMessageBox::critical(this, "警告", "学历不能为小学生、中学生、大学生以外的内容");return;}break;}
            case 1:{flag = check(end, true, false, false);if(!flag) {QMessageBox::critical(this, "警告", "学历不能为小学生以外的内容");return;}break;}
            case 2:{flag = check(end, false, true, false);if(!flag) {QMessageBox::critical(this, "警告", "学历不能为中学生以外的内容");return;}break;}
            case 3:{flag = check(end, false, false, true);if(!flag) {QMessageBox::critical(this, "警告", "学历不能为大学生以外的内容");return;}break;}
        }
        if(!check_(end, 1)) {
            QMessageBox::critical(this, "警告", "学号不能为空");
            return;
        }
        if(!check_(end, 6)) {
            QMessageBox::critical(this, "警告", "用户名不能为空");
            return;
        }
        if(!check_(end, 5)) {
            QMessageBox::critical(this, "警告", "班级不能为空");
            return;
        }
        switch(index) {
            case 0:{flag = check_id(end);break;}
            case 1:{flag = check_id(end, true, false, false);break;}
            case 2:{flag = check_id(end, false, true, false);break;}
            case 3:{flag = check_id(end, false, false, true);break;}
        }
        if(!flag) {
            QMessageBox::critical(this, "警告", "学号重复（表单内重复或与系统内学号重复）");
            return;
        }
        switch(index) {
            case 0:{flag = check_username(end);break;}
            case 1:{flag = check_username(end, true, false, false);break;}
            case 2:{flag = check_username(end, false, true, false);break;}
            case 3:{flag = check_username(end, false, false, true);break;}
        }
        if(!flag) {
            QMessageBox::critical(this, "警告", "用户名重复（表单内重复或与系统内用户名重复）");
            return;
        }
        if(!check_psw(end)) {
            QMessageBox::critical(this, "警告", "密码长度需要为8-15");
            return;
        }
        if(!check_sex(end)){
            QMessageBox::critical(this, "警告", "性别不能为男、女以外的内容");
            return;
        }
        if(!check_age(end)) {
            QMessageBox::critical(this, "警告", "学生不符合入学年龄限制");
            return;
        }
        if(!check_(end, 2)) {
            QMessageBox::critical(this, "警告", "姓名不能为空");
            return;
        }
        if(!check_(end, 5)) {
            QMessageBox::critical(this, "警告", "班级不能为空");
            return;
        }
        if(!check_score(end)) {
            QMessageBox::critical(this, "警告", "学历对应课程错误或课程成绩为空");
            return;
        }
        int ret = QMessageBox::question(this, "选择", "请确定是否保存修改?", QMessageBox::Yes, QMessageBox::No);
        if(ret == QMessageBox::No) {
            QMessageBox::information(this, "提示", "已取消保存！");
            return;
        }
        if(index == 0) {
            std::ofstream ofs("./_id.txt", std::ios::out);
            for (auto i = Student_Manager::ID.begin(); i != Student_Manager::ID.end(); ++i) {//迭代器遍历用户链表，保存身份、账号和密码
                if((**i).get_id() == 1) {
                    ofs << (**i).get_id() << " " << (**i).get_username() << " " << (**i).get_password() << std::endl;
                }
            }
            ofs.close();//关闭文件
        } else if(index == 1) {
            std::ofstream ofs("./_id.txt", std::ios::out);
            for (auto i = Student_Manager::ID.begin(); i != Student_Manager::ID.end(); ++i) {//迭代器遍历用户链表，保存身份、账号和密码
                if((**i).get_id() == 1 || (**i).get_id() == 3 || (**i).get_id() == 4) {
                    ofs << (**i).get_id() << " " << (**i).get_username() << " " << (**i).get_password() << std::endl;
                }
            }
            ofs.close();//关闭文件
        } else if(index == 2) {
            std::ofstream ofs("./_id.txt", std::ios::out);
            for (auto i = Student_Manager::ID.begin(); i != Student_Manager::ID.end(); ++i) {//迭代器遍历用户链表，保存身份、账号和密码
                if((**i).get_id() == 1 || (**i).get_id() == 2 || (**i).get_id() == 4) {
                    ofs << (**i).get_id() << " " << (**i).get_username() << " " << (**i).get_password() << std::endl;
                }
            }
            ofs.close();//关闭文件
        } else {
            std::ofstream ofs("./_id.txt", std::ios::out);
            for (auto i = Student_Manager::ID.begin(); i != Student_Manager::ID.end(); ++i) {//迭代器遍历用户链表，保存身份、账号和密码
                if((**i).get_id() == 1 || (**i).get_id() == 2 || (**i).get_id() == 3) {
                    ofs << (**i).get_id() << " " << (**i).get_username() << " " << (**i).get_password() << std::endl;
                }
            }
            ofs.close();//关闭文件
        }
        if(index != 0 && index != 1) {
            std::ofstream ofs("./_Pri.txt", std::ios::out);//打开小学生文件
            for (auto i = Student_Manager::PSTU.begin(); i !=Student_Manager::PSTU.end(); ++i) {
                ofs << (**i).get_Student_id() << " " << (**i).get_name() << " " << (**i).get_sex() << " " << (**i).get_age() << " " << (**i).get_classname() <<   " " << (**i).get_username() << " " << (**i).get_Chinese() << " " << (**i).get_Math() << " " << (**i).get_English() << std::endl;
            }
            ofs.close();//关闭小学生文件
        }
        if(index != 0 && index != 2) {
            std::ofstream ofs("./_Mid.txt", std::ios::out);//打开中学生文件
            for (auto i = Student_Manager::MSTU.begin(); i != Student_Manager::MSTU.end(); ++i) {
                ofs << (**i).get_Student_id() << " " << (**i).get_name() << " " << (**i).get_sex() << " " << (**i).get_age() << " " << (**i).get_classname() << " " << (**i).get_username() << " " << (**i).get_Chinese() << " " << (**i).get_Math() << " " << (**i).get_English() << " " << (**i).get_Geographic() << " " << (**i).get_History() << std::endl;
            }
            ofs.close();//关闭分数文件
        }
        if(index != 0 && index != 3) {
            std::ofstream ofs("./_Col.txt", std::ios::out);//打开大学生文件
            for (auto i = Student_Manager::CSTU.begin(); i != Student_Manager::CSTU.end(); ++i) {
                ofs << (**i).get_Student_id() << " " << (**i).get_name() << " " << (**i).get_sex() << " " << (**i).get_age() << " " << (**i).get_classname() << " " << (**i).get_username() << " " << (**i).get_Professional() << " " << (**i).get_English() << " " << (**i).get_Program_design() << " " << (**i).get_Advanced_mathematics() << std::endl;
            }
            ofs.close();//关闭分数文件
        }
        Student_Manager::Clear_All_List();
        Student_Manager::PSTU.clear(), Student_Manager::MSTU.clear(), Student_Manager::CSTU.clear(), Student_Manager::ID.clear(), Student_Manager::name_num.clear(), Student_Manager::num_stu.clear(), Student_Manager::unm_id.clear();
        int id;//定义需要输入的内容
        std::string username, password;
        std::ifstream ifs_user("./_id.txt", std::ios::in);
        while (ifs_user >> id && ifs_user >> username && ifs_user >> password) {
            Student_Manager::ID.push_back(new Account(username, password, id));//添加用户
            Student_Manager::unm_id.insert({ username,id });//关联用户和身份
        }
        std::string student_id, name, classname, Username;//定义需要输入的内容
        int sex, age, professional, english, program_design, advance_mathematics, chinese, math, English, geographic, history;
        if(index != 0 && index != 1) {
            std::ifstream ifs_Pri("./_Pri.txt", std::ios::in);
            while (ifs_Pri >> student_id && ifs_Pri >> name && ifs_Pri >> sex && ifs_Pri >> age && ifs_Pri >> classname && ifs_Pri >> Username && ifs_Pri >> chinese && ifs_Pri >> math && ifs_Pri >> English) {
                Primary_student* pstu=new Primary_student(student_id, name, sex, age, classname, 2, Username, English, math, chinese);
                Student_Manager::PSTU.push_back(pstu);//小学生链表增加
                Student_Manager::name_num.insert({ name , student_id });//关联学号和姓名
                Student_Manager::num_stu.insert({ student_id,pstu });//关联学号和学生基本信息
            }
        }
        if(index != 0 && index != 2) {
            std::ifstream ifs_Mid("./_Mid.txt", std::ios::in);
            while (ifs_Mid >> student_id && ifs_Mid >> name && ifs_Mid >> sex && ifs_Mid >> age && ifs_Mid >> classname && ifs_Mid >> Username && ifs_Mid >> chinese && ifs_Mid >> math && ifs_Mid >> English&& ifs_Mid >> geographic && ifs_Mid >> history) {
                Middle_student* mstu = new Middle_student(student_id, name, sex, age, classname, 3, Username, English, math, chinese, geographic, history);
                Student_Manager::MSTU.push_back(mstu);//中学生链表增加
                Student_Manager::name_num.insert({ name , student_id });//关联学号和姓名
                Student_Manager::num_stu.insert({ student_id,mstu });//关联学号和学生基本信息
            }
        }
        if(index != 0 && index != 3) {
            std::ifstream ifs_Col("./_Col.txt", std::ios::in);
            while (ifs_Col >> student_id && ifs_Col >> name && ifs_Col >> sex && ifs_Col >> age && ifs_Col >> classname && ifs_Col >> Username && ifs_Col >> professional && ifs_Col >> english && ifs_Col >> program_design && ifs_Col >> advance_mathematics) {
                College_student* cstu = new College_student(student_id, name, sex, age, classname, 4, Username, professional, english, program_design, advance_mathematics);
                Student_Manager::CSTU.push_back(cstu);//学生链表增加
                Student_Manager::name_num.insert({ name , student_id });//关联学号和姓名
                Student_Manager::num_stu.insert({ student_id,cstu });//关联学号和学生基本信息
            }
        }
        for(int i = 0; i < end; ++i) {
            bool flag = true;
            QString check = ui->list_table->model()->data(ui->list_table->model()->index(i, 0)).toString();
            student_id = Student_Manager::ToString(ui->list_table->model()->data(ui->list_table->model()->index(i, 1)).toString());
            name = Student_Manager::ToString(ui->list_table->model()->data(ui->list_table->model()->index(i, 2)).toString());
            sex = (ui->list_table->model()->data(ui->list_table->model()->index(i, 3)).toString() == "男") ? 1 : 2;
            age = ui->list_table->model()->data(ui->list_table->model()->index(i, 4)).toString().toInt();
            classname = Student_Manager::ToString(ui->list_table->model()->data(ui->list_table->model()->index(i, 5)).toString());
            Username = Student_Manager::ToString(ui->list_table->model()->data(ui->list_table->model()->index(i, 6)).toString());
            password = Student_Manager::ToString(ui->list_table->model()->data(ui->list_table->model()->index(i, 7)).toString());
            if(check == "小学生") {
                chinese = ui->list_table->model()->data(ui->list_table->model()->index(i, 8)).toString().toInt();
                math = ui->list_table->model()->data(ui->list_table->model()->index(i, 9)).toString().toInt();
                English = ui->list_table->model()->data(ui->list_table->model()->index(i, 10)).toString().toInt();
                Primary_student* pstu=new Primary_student(student_id, name, sex, age, classname, 2, Username, English, math, chinese);
                Student_Manager::PSTU.push_back(pstu);//小学生链表增加
                Student_Manager::name_num.insert({ name , student_id });//关联学号和姓名
                Student_Manager::num_stu.insert({ student_id,pstu });//关联学号和学生基本信息
                Student_Manager::ID.push_back(new Account(Username, password, 2));//添加用户
                Student_Manager::unm_id.insert({ Username,2 });//关联用户和身份
            } else if(check == "中学生") {
                chinese = ui->list_table->model()->data(ui->list_table->model()->index(i, 8)).toString().toInt();
                math = ui->list_table->model()->data(ui->list_table->model()->index(i, 9)).toString().toInt();
                English = ui->list_table->model()->data(ui->list_table->model()->index(i, 10)).toString().toInt();
                geographic = ui->list_table->model()->data(ui->list_table->model()->index(i, 11)).toString().toInt();
                history = ui->list_table->model()->data(ui->list_table->model()->index(i, 12)).toString().toInt();
                Middle_student* mstu = new Middle_student(student_id, name, sex, age, classname, 3, Username, English, math, chinese, geographic, history);
                Student_Manager::MSTU.push_back(mstu);//中学生链表增加
                Student_Manager::name_num.insert({ name , student_id });//关联学号和姓名
                Student_Manager::num_stu.insert({ student_id,mstu });//关联学号和学生基本信息
                Student_Manager::ID.push_back(new Account(Username, password, 3));//添加用户
                Student_Manager::unm_id.insert({ Username,3 });//关联用户和身份
            } else {
                professional = ui->list_table->model()->data(ui->list_table->model()->index(i, 13)).toString().toInt();
                english = ui->list_table->model()->data(ui->list_table->model()->index(i, 10)).toString().toInt();
                program_design = ui->list_table->model()->data(ui->list_table->model()->index(i, 14)).toString().toInt();
                advance_mathematics = ui->list_table->model()->data(ui->list_table->model()->index(i, 15)).toString().toInt();
                College_student* cstu = new College_student(student_id, name, sex, age, classname, 4, Username, professional, english, program_design, advance_mathematics);
                Student_Manager::CSTU.push_back(cstu);//学生链表增加
                Student_Manager::name_num.insert({ name , student_id });//关联学号和姓名
                Student_Manager::num_stu.insert({ student_id,cstu });//关联学号和学生基本信息
                Student_Manager::ID.push_back(new Account(Username, password, 4));//添加用户
                Student_Manager::unm_id.insert({ Username,4 });//关联用户和身份
            }
        }
        QMessageBox::information(this, "成功", "已成功保存！");
    });
}

Change_Person::~Change_Person() {
    delete ui;
}

void Change_Person::paintEvent(QPaintEvent *){
    QPainter painter(this);
    QPixmap pix;
    pix.load(":/image/School.png");
    pix = pix.scaled(pix.width() * 0.2, pix.height() * 0.2);
    painter.drawPixmap(0, 10, pix);
}

bool Change_Person::check_score(int num) {
    bool Check = true;
    for(int i = 0; i < num; ++i) {
        bool flag = true;
        QString check = ui->list_table->model()->data(ui->list_table->model()->index(i, 0)).toString();

        if(check == "小学生") {
            for(int j = 8; j <= 15; ++j) {
                if(j <= 10) {
                    if(ui->list_table->model()->data(ui->list_table->model()->index(i, j)).toString().isEmpty()){
                        flag = false;
                    }
                } else {
                    if(!ui->list_table->model()->data(ui->list_table->model()->index(i, j)).toString().isEmpty()){
                        flag = false;
                    }
                }
            }
        } else if(check == "中学生") {
            for(int j = 8; j <= 15; ++j) {
                if(j <= 12) {
                    if(ui->list_table->model()->data(ui->list_table->model()->index(i, j)).toString().isEmpty()){
                        flag = false;
                    }
                } else {
                    if(!ui->list_table->model()->data(ui->list_table->model()->index(i, j)).toString().isEmpty()){
                        flag = false;
                    }
                }
            }
        } else {
            for(int j = 8; j <= 15; ++j) {
                if(j == 10 || j >= 13) {
                    if(ui->list_table->model()->data(ui->list_table->model()->index(i, j)).toString().isEmpty()){
                        flag = false;
                    }
                } else {
                    if(!ui->list_table->model()->data(ui->list_table->model()->index(i, j)).toString().isEmpty()){
                        flag = false;
                    }
                }
            }
        }
        if(!flag) {
            Check = false;
            ui->list_table->selectRow(i);
        }
    }
    return Check;
}

bool Change_Person::check_(int num, int j) {
    bool Check = true;
    for(int i = 0; i < num; ++i) {
        QString check = ui->list_table->model()->data(ui->list_table->model()->index(i, j)).toString();
        if(check.isEmpty()) {
            Check = false;
            ui->list_table->selectRow(i);
        }
    }
    return Check;
}

bool Change_Person::check_username(int num, bool Pri, bool Mid, bool Col) {
    bool Check = true;
    std::unordered_map<QString,int>mp;
    for(int i = 0; i < num; ++i) {
        QString check = ui->list_table->model()->data(ui->list_table->model()->index(i, 6)).toString();
        if(mp.count(check)) {
            Check = false;
            ui->list_table->selectRow(i);
        }
        mp.insert({check, 1});
        if(Student_Manager::unm_id.count(Student_Manager::ToString(check))) {
            if(Student_Manager::unm_id[Student_Manager::ToString(check)] == 2 && !Pri) {
                Check = false;
                ui->list_table->selectRow(i);
            } else if(Student_Manager::unm_id[Student_Manager::ToString(check)] == 3 && !Mid) {
                Check = false;
                ui->list_table->selectRow(i);
            } else if(Student_Manager::unm_id[Student_Manager::ToString(check)] == 4 && !Col) {
                Check = false;
                ui->list_table->selectRow(i);
            }
        }
    }
    return Check;
}


bool Change_Person::check_id(int num, bool Pri, bool Mid, bool Col) {
    bool Check = true;
    std::unordered_map<QString,int>mp;
    for(int i = 0; i < num; ++i) {
        QString check = ui->list_table->model()->data(ui->list_table->model()->index(i, 1)).toString();
        if(mp.count(check)) {
            Check = false;
            ui->list_table->selectRow(i);
        }
        mp.insert({check, 1});
        if(Student_Manager::num_stu.count(Student_Manager::ToString(check))) {
            if(Student_Manager::num_stu[Student_Manager::ToString(check)]->get_grade() == 2 && !Pri) {
                Check = false;
                ui->list_table->selectRow(i);
            } else if(Student_Manager::num_stu[Student_Manager::ToString(check)]->get_grade() == 3 && !Mid) {
                Check = false;
                ui->list_table->selectRow(i);
            } else if(Student_Manager::num_stu[Student_Manager::ToString(check)]->get_grade() == 4 && !Col) {
                Check = false;
                ui->list_table->selectRow(i);
            }
        }
    }
    return Check;
}

bool Change_Person::check_psw(int num) {
    bool Check = true;
    for(int i = 0; i < num; ++i) {
        QString check = ui->list_table->model()->data(ui->list_table->model()->index(i, 7)).toString();
        if(check.length() < 8) {
            Check = false;
            ui->list_table->selectRow(i);
        }
    }
    return Check;
}

bool Change_Person::check_age(int num) {
    bool Check = true;
    for(int i = 0; i < num; ++i) {
        int check = ui->list_table->model()->data(ui->list_table->model()->index(i, 4)).toString().toInt();
        if(check < 8 || check > 25) {
            Check = false;
            ui->list_table->selectRow(i);
        }
    }
    return Check;
}

bool Change_Person::check_sex(int num) {
    bool Check = true;
    for(int i = 0; i < num; ++i) {
        QString check = ui->list_table->model()->data(ui->list_table->model()->index(i, 3)).toString();
        if(check != "男" && check!= "女") {
            Check = false;
            ui->list_table->selectRow(i);
        }
    }
    return Check;
}

bool Change_Person::check(int end, bool Pri, bool Mid, bool Col) {
    bool Check = true;
    for(int i = 0; i < end; ++i) {
        bool flag = false;
        if(Pri && ui->list_table->model()->data(ui->list_table->model()->index(i, 0)).toString() == "小学生") {
            flag = true;
        }
        if(Mid && ui->list_table->model()->data(ui->list_table->model()->index(i, 0)).toString() == "中学生") {
            flag = true;
        }
        if(Col && ui->list_table->model()->data(ui->list_table->model()->index(i, 0)).toString() == "大学生") {
            flag = true;
        }
        if(!flag) {
            Check = false;
            ui->list_table->selectRow(i);
        }
    }
    return Check;
}
//更新查找学生信息
void Change_Person::search() {
    if(ui->get_line->text().isEmpty()) {
        QMessageBox::critical(this, "警告", "查找内容不能为空！");
        return;
    }
    std::string Student_id = Student_Manager::ToString(ui->get_line->text());
    if (Student_Manager::num_stu.count(Student_id)) {//用学号进行查询，如果哈希表内有该成员，避免使用[]造成不必要的插入
        Student* stu = Student_Manager::num_stu[Student_id];
        ui->id_line->setText(ui->get_line->text());
        ui->username_line->setText(QString::fromLocal8Bit(stu->get_username()));
        ui->name_line->setText(QString::fromLocal8Bit(stu->get_name()));
        ui->classname_line->setText(QString::fromLocal8Bit(stu->get_classname()));
        ui->age->setCurrentIndex(stu->get_age() - 8);
        if(stu->get_sex() == 1) {
            ui->boy_btn->setChecked(true);
            ui->stackedWidget->setCurrentIndex(0);
        } else {
            ui->girl_btn->setChecked(true);
            ui->stackedWidget->setCurrentIndex(1);
        }
        if(stu->get_grade() == 4) {
            ui->tabWidget->setCurrentIndex(2);
            ui->Col_professional->setText(QString::number(((College_student*)stu)->get_Professional()));
            ui->Col_english->setText(QString::number(((College_student*)stu)->get_English()));
            ui->Col_program_design->setText(QString::number(((College_student*)stu)->get_Program_design()));
            ui->Col_Ad_math->setText(QString::number(((College_student*)stu)->get_Advanced_mathematics()));
        } else if(stu->get_grade() == 2) {
            ui->tabWidget->setCurrentIndex(0);
            ui->Pri_chinese->setText(QString::number(((Primary_student*)stu)->get_Chinese()));
            ui->Pri_math->setText(QString::number(((Primary_student*)stu)->get_Math()));
            ui->Pri_english->setText(QString::number(((Primary_student*)stu)->get_English()));
        } else {
            ui->tabWidget->setCurrentIndex(1);
            ui->Mid_chinese->setText(QString::number(((Primary_student*)stu)->get_Chinese()));
            ui->Mid_math->setText(QString::number(((Primary_student*)stu)->get_Math()));
            ui->Mid_english->setText(QString::number(((Primary_student*)stu)->get_English()));
            ui->Mid_geographic->setText(QString::number(((Middle_student*)stu)->get_Geographic()));
            ui->Mid_history->setText(QString::number(((Middle_student*)stu)->get_History()));
        }
    } else {//哈希表内没有该成员
        QMessageBox::critical(this, "错误", "查询不到该学生！");
    }
}

void Change_Person::init() {

    //设置默认位置
    ui->stackedWidget->setCurrentIndex(0);
    ui->view->setCurrentIndex(0);
    curr_index = 0;

    //设置默认内容
    ui->age->setCurrentIndex(4);

    //设置默认按钮
    ui->boy_btn->setChecked(true);

    //设置默认学历
    ui->tabWidget->setCurrentIndex(0);

    //设置默认内容
    ui->get_line->setText("");

    ui->password_line->setText("");
    ui->password_check->setText("");
    ui->name_line->setText("");
    ui->username_line->setText("");
    ui->id_line->setText("");
    ui->classname_line->setText("");

    ui->Pri_chinese->setText("");
    ui->Pri_math->setText("");
    ui->Pri_english->setText("");

    ui->Mid_chinese->setText("");
    ui->Mid_math->setText("");
    ui->Mid_english->setText("");
    ui->Mid_geographic->setText("");
    ui->Mid_history->setText("");

    ui->Col_professional->setText("");
    ui->Col_english->setText("");
    ui->Col_program_design->setText("");
    ui->Col_Ad_math->setText("");
}

void Change_Person::init_2() {
    ui->screen->setCurrentIndex(0);
    ui->find_way->setCurrentIndex(0);
    ui->check_line->setText("");
    Student_Manager::Sort_Function(13);
    init_all();
}
void Change_Person::create_table(bool Pri, bool Mid, bool Col) {
    int count = 0;
    //设置表头
    QStringList headers;
    QStandardItemModel *models = new QStandardItemModel();
    headers<<"学历"<<"学号"<<"姓名"<<"性别"<<"年龄"<<"班级"<<"用户名"<<"密码"<<"语文"<<"数学"<<"英语"<<"地理"<<"历史"<<"专业"<<"程设"<<"高数";
    models->setHorizontalHeaderLabels(headers);
    count = 0;
    //添加数据，主表单部分
    std::unordered_map<std::string,int>mp;
    if(Pri) {
        auto Pbegin = Student_Manager::PSTU.rbegin();
        auto Pend = Student_Manager::PSTU.rend();
        for(auto i = Pbegin; i != Pend; ++i, ++count) {
            models->setItem(count, 0, new QStandardItem("小学生"));
            models->setItem(count, 1, new QStandardItem(QString::fromLocal8Bit((**i).get_Student_id())));
            models->setItem(count, 2, new QStandardItem(QString::fromLocal8Bit((**i).get_name())));
            models->setItem(count, 3, new QStandardItem((**i).get_sex() == 1?"男":"女"));
            models->setItem(count, 4, new QStandardItem(QString::number((**i).get_age())));
            models->setItem(count, 5, new QStandardItem(QString::fromLocal8Bit((**i).get_classname())));
            models->setItem(count, 6, new QStandardItem(QString::fromLocal8Bit((**i).get_username())));
            models->setItem(count, 8, new QStandardItem(QString::number((**i).get_Chinese())));
            models->setItem(count, 9, new QStandardItem(QString::number((**i).get_Math())));
            models->setItem(count, 10, new QStandardItem(QString::number((**i).get_English())));
            mp.insert({((**i).get_username()),count});
        }
    }
    if(Mid) {
        auto Mbegin = Student_Manager::MSTU.rbegin();
        auto Mend = Student_Manager::MSTU.rend();
        for(auto i = Mbegin; i != Mend; ++i, ++count) {
            models->setItem(count, 0, new QStandardItem("中学生"));
            models->setItem(count, 1, new QStandardItem(QString::fromLocal8Bit((**i).get_Student_id())));
            models->setItem(count, 2, new QStandardItem(QString::fromLocal8Bit((**i).get_name())));
            models->setItem(count, 3, new QStandardItem((**i).get_sex() == 1?"男":"女"));
            models->setItem(count, 4, new QStandardItem(QString::number((**i).get_age())));
            models->setItem(count, 5, new QStandardItem(QString::fromLocal8Bit((**i).get_classname())));
            models->setItem(count, 6, new QStandardItem(QString::fromLocal8Bit((**i).get_username())));
            models->setItem(count, 8, new QStandardItem(QString::number((**i).get_Chinese())));
            models->setItem(count, 9, new QStandardItem(QString::number((**i).get_Math())));
            models->setItem(count, 10, new QStandardItem(QString::number((**i).get_English())));
            models->setItem(count, 11, new QStandardItem(QString::number((**i).get_Geographic())));
            models->setItem(count, 12, new QStandardItem(QString::number((**i).get_History())));
            mp.insert({((**i).get_username()),count});
        }
    }
    if(Col) {
        auto Cbegin = Student_Manager::CSTU.rbegin();
        auto Cend = Student_Manager::CSTU.rend();
        for(auto i = Cbegin; i != Cend; ++i, ++count) {
            models->setItem(count, 0, new QStandardItem("大学生"));
            models->setItem(count, 1, new QStandardItem(QString::fromLocal8Bit((**i).get_Student_id())));
            models->setItem(count, 2, new QStandardItem(QString::fromLocal8Bit((**i).get_name())));
            models->setItem(count, 3, new QStandardItem((**i).get_sex() == 1?"男":"女"));
            models->setItem(count, 4, new QStandardItem(QString::number((**i).get_age())));
            models->setItem(count, 5, new QStandardItem(QString::fromLocal8Bit((**i).get_classname())));
            models->setItem(count, 6, new QStandardItem(QString::fromLocal8Bit((**i).get_username())));
            models->setItem(count, 13, new QStandardItem(QString::number((**i).get_Professional())));
            models->setItem(count, 14, new QStandardItem(QString::number((**i).get_Program_design())));
            models->setItem(count, 10, new QStandardItem(QString::number((**i).get_English())));
            models->setItem(count, 15, new QStandardItem(QString::number((**i).get_Advanced_mathematics())));
            mp.insert({((**i).get_username()),count});
        }
    }
    for(auto i = Student_Manager::ID.begin(); i != Student_Manager::ID.end(); ++i) {
        if(mp.count((**i).get_username())) {
            models->setItem(mp[(**i).get_username()], 7, new QStandardItem(QString::fromLocal8Bit((**i).get_password())));
        }
    }
    QRegularExpression psw("[a-zA-Z0-9]{8,15}+$");
    ui->list_table->setItemDelegateForColumn(7, new CustomItemDelegrate(psw));
    QRegularExpression _digit("^\\d{2}$");
    QRegularExpression only_digit("^\\d{3}$");
    ui->list_table->setItemDelegateForColumn(4, new CustomItemDelegrate(_digit));
    for(int i = 8; i <= 15; ++i) {
        ui->list_table->setItemDelegateForColumn(i, new CustomItemDelegrate(only_digit));
    }
    ui->list_table->horizontalHeader()->setStretchLastSection(true);
    ui->list_table->setModel(models);
}

void Change_Person::init_all() {
    create_table();
}

void Change_Person::init_pri() {
    create_table(true, false, false);
}

void Change_Person::init_mid() {
    create_table(false, true, false);
}

void Change_Person::init_col() {
    create_table(false, false, true);
}
