#include "primary_class.h"
Primary_class::Primary_class(int english,int math, int chinese){
    English = english, Math = math, Chinese = chinese;
    English_sum += english, Math_sum += math, Chinese_sum += chinese;//加入到总分
}
Primary_class::~Primary_class() {
    English_sum -= English, Math_sum -= Math, Chinese_sum -= Chinese;
}
int Primary_class::get_English() {
    return English;
}
int Primary_class::get_Math() {
    return Math;
}
int Primary_class::get_Chinese() {
    return Chinese;
}
int Primary_class::get_pri_sum() {
    return Chinese + Math + English;
}
int Primary_class::Chinese_sum = 0;
int Primary_class::Math_sum = 0;
int Primary_class::English_sum = 0;
int Primary_class::get_English_sum() {
    return English_sum;
}
int Primary_class::get_Math_sum() {
    return Math_sum;
}
int Primary_class::get_Chinese_sum() {
    return Chinese_sum;
}
int Primary_class::get_All_sum() {
    return English_sum + Math_sum + Chinese_sum;
}
