#include "delete_manager.h"
#include "ui_delete_manager.h"

Delete_Manager::Delete_Manager(QWidget *parent) : QWidget(parent), ui(new Ui::Delete_Manager) {
    ui->setupUi(this);

    //设置图标
    setWindowIcon(QIcon(":/image/School.png"));

    //设置标题
    setWindowTitle("学生成绩管理系统");

    //关联返回键
    connect(ui->exit_btn, &QPushButton::clicked, [=](){
        emit this->choice_return();
    });

    //关联删除键
    connect(ui->delete_btn, &QPushButton::clicked, [=](){
        if(ui->get_line->text().isEmpty()) {
            QMessageBox::critical(this, "警告", "删除信息框内不能为空!");
            return;
        }
        std::string username = Student_Manager::ToString(ui->get_line->text());
        if (username == Student_Manager::Username) {//能执行删除操作的只能是老师
            QMessageBox::critical(this, "警告", "您不能删除您自己的账户!");
            return;
        }
        if (Student_Manager::unm_id.count(username)) {//找到了
            int ret = QMessageBox::question(this, "选择", "请确认是否対该账号进行删除", QMessageBox::Yes, QMessageBox::No);
            if(ret == QMessageBox::No) {
                QMessageBox::information(this, "提示", "已取消删除！");
                return;
            }
            if (Student_Manager::unm_id[username] == 1) {//身份是老师
                Student_Manager::remove(Student_Manager::ID, username);//清除账号
                Student_Manager::unm_id.erase(username);//消除关联容器的影响
                QMessageBox::information(this, "成功", "删除账户成功！");
            } else {//身份不是老师
                QMessageBox::critical(this, "警告", "您删除的账户的使用者不是老师！");
            }
        } else {//没这账户
            QMessageBox::critical(this, "错误", "查询不到该账户！");
        }
    });
}

Delete_Manager::~Delete_Manager() {
    delete ui;
}


void Delete_Manager::paintEvent(QPaintEvent *){
    QPainter painter(this);
    QPixmap pix;
    pix.load(":/image/School.png");
    pix = pix.scaled(pix.width() * 0.1, pix.height() * 0.1);
    painter.drawPixmap(0, 10, pix);
}

void Delete_Manager::init() {

}
