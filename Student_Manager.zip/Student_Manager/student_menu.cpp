#include "student_menu.h"
#include "change_psw.h"
#include "ui_student_menu.h"

Student_Menu::Student_Menu(QWidget *parent) : QWidget(parent), ui(new Ui::Student_Menu) {
    ui->setupUi(this);

    //设置固定大小
    setFixedSize(1200, 800);

    //设置图标
    setWindowIcon(QIcon(":/image/School.png"));

    //设置标题
    setWindowTitle("学生成绩管理系统");

    //去除groupBox类的白边
    ui->groupBox->setStyleSheet("QGroupBox{border:none}");

    flag = true;

    //设置返回信号
    connect(ui->return_btn, &QPushButton::clicked,[=](){
        if(!flag) {
            int ret = QMessageBox::question(this, "选择", "文件内可能存在未保存信息，是否保存？", QMessageBox::Yes, QMessageBox::No);
            if(ret == QMessageBox::Yes) {
                emit this->save();
                QMessageBox::information(this, "保存成功", "保存成功！");
                flag = true;
            }
        }
        emit this->choice_return();
    });

    //关联退出键
    connect(ui->exit_btn, &QPushButton::clicked, [=](){
        if(!flag) {
            int ret = QMessageBox::question(this, "选择", "文件内可能存在未保存信息，是否保存？", QMessageBox::Yes, QMessageBox::No);
            if(ret == QMessageBox::Yes) {
                emit this->save();
                QMessageBox::information(this, "保存成功", "保存成功！");
                flag = true;
            }
        }
        this->close();
    });

    sort_and_check* sc = new sort_and_check;
    Find_Person* fp = new Find_Person;
    Change_psw* cp = new Change_psw;
    //关联查询键
    connect(ui->show_btn, &QPushButton::clicked, [=](){
        this->hide();
        sc->init();
        sc->show();
        sc->setGeometry(this->geometry());
    });

    //关联查找键
    connect(ui->check_btn, &QPushButton::clicked, [=](){
        this->hide();
        fp->init();
        fp->show();
        fp->setGeometry(this->geometry());
    });

    //关联修改键
    connect(ui->change_btn, &QPushButton::clicked, [=](){
        flag = false;
        cp->init();
        cp->show();
    });

    //关联读取键
    connect(ui->read_btn, &QPushButton::clicked, [=](){
        int ret = QMessageBox::question(this, "选择", "是否重新读取信息", QMessageBox::Yes, QMessageBox::No);
        if(ret == QMessageBox::Yes) {
            emit this->init();
            QMessageBox::information(this, "读取成功", "保存成功！");
            flag = false;
        }
    });

    //关联保存键
    connect(ui->save_btn, &QPushButton::clicked, [=](){
        int ret = QMessageBox::question(this, "选择", "是否保存您的更改", QMessageBox::Yes, QMessageBox::No);
        if(ret == QMessageBox::Yes) {
            emit this->save();
            QMessageBox::information(this, "保存成功", "保存成功！");
            flag = true;
        }
    });

    //监听返回
    connect(sc, &sort_and_check::choice_return, this, [=](){
        sc->close();
        this->show();
        this->setGeometry(sc->geometry());//设置位置保持一致
    });


    connect(fp, &Find_Person::choice_return, this, [=](){
        fp->close();
        this->show();
        this->setGeometry(fp->geometry());//设置位置保持一致
    });

    connect(cp, &Change_psw::choice_return, this, [=](){
        cp->close();
    });

}

Student_Menu::~Student_Menu() {
    delete ui;
}

void Student_Menu::paintEvent(QPaintEvent *){
    QPainter painter(this);
    QPixmap pix;
    pix.load(":/image/School.png");
    pix = pix.scaled(pix.width() * 0.35, pix.height() * 0.35);
    painter.drawPixmap(0, 10, pix);
}
