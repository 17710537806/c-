#include "primary_student.h"
Primary_student::Primary_student(std::string student_id, std::string Name, int Sex, int Age, std::string Classname, int Grade, std::string Username, int english, int math, int chinese)
: Student(student_id, Name, Sex, Age, Classname, Grade, Username), Primary_class(english, math, chinese) {}
