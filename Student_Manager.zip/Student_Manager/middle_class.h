#ifndef MIDDLE_CLASS_H
#define MIDDLE_CLASS_H

class Middle_class {
private://保护数据安全
    int Geographic;//地理成绩
    int History;//历史成绩
    static int Geographic_sum;//地理分数总和
    static int History_sum;//历史分数总和
public:
    Middle_class(int geographic, int history);//有参构造
    ~Middle_class();//消除加入到总分带来的影响
    int get_Geographic();//获取内部成员函数接口
    int get_History();
    int get_mid_sum();//求成绩总和
    static int get_Geographic_sum();
    static int get_History_sum();
    static int get_All_sum();
};

#endif // MIDDLE_CLASS_H
