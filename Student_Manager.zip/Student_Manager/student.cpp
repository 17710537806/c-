#include"Student.h"
Student::Student(std::string Username) {
    username = Username;
}
Student::Student(std::string student_id, std::string Name, int Sex, int Age, std::string Classname, int Grade, std::string Username) {
    Student_id = student_id, name = Name, sex = Sex, age = Age, classname = Classname, grade = Grade, username = Username;
}
std::string Student::get_Student_id() {
    return Student_id;
}
std::string Student::get_name() {
    return name;
}
int Student::get_sex() {
    return sex;
}
int Student::get_age() {
    return age;
}
std::string Student::get_classname() {
    return classname;
}
int Student::get_grade() {
    return grade;
}
std::string Student::get_username() {
    return username;
}
