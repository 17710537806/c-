#ifndef MENU_H
#define MENU_H
#include<QWidget>
#include<QPaintEvent>
#include<QPainter>
#include<sort_and_check.h>
#include<add_person.h>
#include<find_person.h>
#include<delete_person.h>
#include<change_person.h>
#include<QFile>
#include<QDir>
#include<QAxObject>
#include<vector>
namespace Ui {
class Menu;
}

class Menu : public QWidget
{
    Q_OBJECT

public:
    explicit Menu(QWidget *parent = nullptr);

    ~Menu();
signals:
    //设置返回信号
    void choice_return();

    //设置保存信号
    void save();

    //设置读取信号
    void init();

    void read_new();

private:
    Ui::Menu *ui;

    bool flag;
    //画背景图
    void paintEvent(QPaintEvent *);
};

#endif // MENU_H
