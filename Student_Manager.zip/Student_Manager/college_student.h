#ifndef COLLEGE_STUDENT_H
#define COLLEGE_STUDENT_H
#include<student.h>
#include<college_class.h>
#include<string>
class College_student : public Student, public College_class {
public:
    //有参构造
    College_student(std::string student_id, std::string Name, int Sex, int Age, std::string Classname, int Grade, std::string Username, int professional, int english, int program_design, int advanced_mathematics);
};
#endif // COLLEGE_STUDENT_H
