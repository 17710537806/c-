#ifndef GLOBALFILE_H
#define GLOBALFILE_H
constexpr auto User_File = "User.txt";//用户密码文件
constexpr auto Pri_File = "pri_stu.txt";//分数文件;
constexpr auto Mid_File = "mid_stu.txt";//分数文件;
constexpr auto Col_File = "col_stu.txt";//分数文件;
#endif // GLOBALFILE_H
