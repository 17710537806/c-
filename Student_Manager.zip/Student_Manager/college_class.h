#ifndef COLLEGE_CLASS_H
#define COLLEGE_CLASS_H


class College_class{
private://保护数据安全
    int Professional;//专业
    int English;//英语
    int Program_design;//程序设计
    int Advanced_mathematics;//高等数学
    static int Professional_sum;//专业分数总和
    static int English_sum;//英语分数总和
    static int Program_design_sum;//程序设计分数总和
    static int Advanced_mathematics_sum;//高等数学分数总和
public:
    College_class(int professional, int english, int program_design, int advanced_mathematics);
    ~College_class();//析构函数，用来清除对静态成员的影响
    int get_Professional();//获取内部成员函数接口
    int get_English();
    int get_Program_design();
    int get_Advanced_mathematics();
    int get_all_sum();//求成绩合
    static int get_Professional_sum();
    static int get_English_sum();
    static int get_Program_design_sum();
    static int get_Advanced_mathematics_sum();
    static int get_All_sum();
};
#endif // COLLEGE_CLASS_H
