#include "change_manager.h"
#include "ui_change_manager.h"

Change_Manager::Change_Manager(QWidget *parent) : QWidget(parent), ui(new Ui::Change_Manager) {
    ui->setupUi(this);

    //设置图标
    setWindowIcon(QIcon(":/image/School.png"));

    //设置标题
    setWindowTitle("学生成绩管理系统");

    //利用正则表达式控制输入
    ui->psw_fir_line->setValidator(new QRegularExpressionValidator(QRegularExpression("[a-zA-Z0-9]+$")));
    ui->psw_sec_line->setValidator(new QRegularExpressionValidator(QRegularExpression("[a-zA-Z0-9]+$")));

    //设置最多位数
    ui->psw_fir_line->setMaxLength(15);
    ui->psw_sec_line->setMaxLength(15);

    connect(ui->exit_btn, &QPushButton::clicked, this, [=](){
        emit this->choice_return();
    });

    connect(ui->change_btn, &QPushButton::clicked, this, [=](){
        if(ui->count_line->text().isEmpty()) {
            QMessageBox::critical(this, "警告", "账户不能为空");
            return;
        }
        if(ui->psw_fir_line->text() != ui->psw_sec_line->text()) {
            QMessageBox::critical(this, "警告", "两次密码输入不一致");
            return;
        }
        if(ui->psw_fir_line->text().length() < 8) {
            QMessageBox::critical(this, "警告", "密码需在8-15位之间");
            return;
        }
        std::string username = Student_Manager::ToString(ui->count_line->text());
        if (!Student_Manager::unm_id.count(username)) {
            QMessageBox::critical(this, "警告", "查无此人");
            return;
        } else {
            int ret;
            if(Student_Manager::unm_id[username] == 1) {
                ret = QMessageBox::question(this, "选择", "请确认是否修改该老师账户密码?", QMessageBox::Yes, QMessageBox::No);
            } else {
                ret = QMessageBox::question(this, "选择", "请确认是否修改该学生账户密码?", QMessageBox::Yes, QMessageBox::No);
            }
            if(ret == QMessageBox::No) {
                QMessageBox::information(this, "提示", "已取消修改！");
                return;
            }
            std::string password = Student_Manager::ToString(ui->psw_fir_line->text());
            Account* Ac = new Account(username, password, Student_Manager::unm_id[username]);//添加账号
            Student_Manager::remove(Student_Manager::ID, username);
            Student_Manager::ID.push_back(Ac);
            QMessageBox::information(this, "成功", "修改密码成功！");
        }
    });
}

Change_Manager::~Change_Manager() {
    delete ui;
}

void Change_Manager::paintEvent(QPaintEvent *){
    QPainter painter(this);
    QPixmap pix;
    pix.load(":/image/School.png");
    pix = pix.scaled(pix.width() * 0.1, pix.height() * 0.1);
    painter.drawPixmap(0, 5, pix);
}
