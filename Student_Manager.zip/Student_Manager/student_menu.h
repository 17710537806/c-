#ifndef STUDENT_MENU_H
#define STUDENT_MENU_H

#include <QWidget>
#include<QPaintEvent>
#include<QPainter>
#include<sort_and_check.h>
#include<add_person.h>
#include<find_person.h>
#include<delete_person.h>
#include<change_person.h>
namespace Ui {
class Student_Menu;
}

class Student_Menu : public QWidget
{
    Q_OBJECT

public:
    explicit Student_Menu(QWidget *parent = nullptr);
    ~Student_Menu();

signals:
    //设置返回信号
    void choice_return();

    //设置保存信号
    void save();

    //设置读取信号
    void init();

private:
    Ui::Student_Menu *ui;

    bool flag;

    //画背景图
    void paintEvent(QPaintEvent *);
};

#endif // STUDENT_MENU_H
