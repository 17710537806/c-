#include "menu.h"
#include "ui_menu.h"
#include<QPainter>
#include<QPushButton>

Menu::Menu(QWidget *parent) : QWidget(parent), ui(new Ui::Menu){
    ui->setupUi(this);
    //设置固定大小
    setFixedSize(1200, 800);

    //设置图标
    setWindowIcon(QIcon(":/image/School.png"));

    //设置标题
    setWindowTitle("学生成绩管理系统");

    //去除groupBox类的白边
    ui->groupBox->setStyleSheet("QGroupBox{border:none}");

    //设置返回信号
    connect(ui->return_btn, &QPushButton::clicked,[=](){
        if(!flag) {
            int ret = QMessageBox::question(this, "选择", "文件内可能存在未保存信息，是否保存？", QMessageBox::Yes, QMessageBox::No);
            if(ret == QMessageBox::Yes) {
                emit this->save();
                QMessageBox::information(this, "保存成功", "保存成功！");
                flag = true;
            }
        }
        emit this->choice_return();
    });

    //关联退出键
    connect(ui->exit_btn, &QPushButton::clicked, [=](){
        if(!flag) {
            int ret = QMessageBox::question(this, "选择", "文件内可能存在未保存信息，是否保存？", QMessageBox::Yes, QMessageBox::No);
            if(ret == QMessageBox::Yes) {
                emit this->save();
                QMessageBox::information(this, "保存成功", "保存成功！");
                flag = true;
            }
        }
        this->close();
    });

    sort_and_check* sc = new sort_and_check;
    Add_Person* ap = new Add_Person;
    Find_Person* fp = new Find_Person;
    Delete_Person* dp = new Delete_Person;
    Change_Person* cp = new Change_Person;


    flag = true;

    //关联编辑键
    connect(ui->change_btn, &QPushButton::clicked, [=]{
        this->hide();
        cp->init();
        cp->init_2();
        cp->show();
        cp->setGeometry(this->geometry());
    });

    //关联查询键
    connect(ui->show_btn, &QPushButton::clicked, [=](){
        this->hide();
        sc->init();
        sc->show();
        sc->setGeometry(this->geometry());
    });

    //关联查找键
    connect(ui->check_btn, &QPushButton::clicked, [=](){
        this->hide();
        fp->init();
        fp->show();
        fp->setGeometry(this->geometry());
    });

    //关联添加键
    connect(ui->add_btn, &QPushButton::clicked, [=](){
        this->hide();
        ap->init();
        ap->show();
        ap->setGeometry(this->geometry());
    });

    //关联删除键
    connect(ui->delete_btn, &QPushButton::clicked,[=](){
        this->hide();
        dp->init();
        dp->show();
        //给用户提示
        QMessageBox::information(this, "提示", "请使用学号进行查询！");
        dp->setGeometry(this->geometry());
    });

    //关联保存键
    connect(ui->save_btn, &QPushButton::clicked, [=](){
        QMessageBox addBox;
        addBox.setStandardButtons(QMessageBox::Save | QMessageBox::Discard | QMessageBox::Cancel);
        addBox.setIcon(QMessageBox::Information);
        addBox.setWindowTitle("保存");
        addBox.setText("请选择保存内容");
        addBox.button(QMessageBox::Save)->setText("保存数据");
        addBox.button(QMessageBox::Discard)->setText("导出表单至exc");
        addBox.button(QMessageBox::Cancel)->setText("取消保存");
        addBox.setDefaultButton(QMessageBox::Cancel);
        int ret = addBox.exec();
        if(ret == QMessageBox::Save) {
            emit this->save();
            QMessageBox::information(this, "保存成功", "保存成功！");
            flag = true;
        } else if (ret == QMessageBox::Discard) {
            sc->save();
        }
    });

    //关联读取键
    connect(ui->read_btn, &QPushButton::clicked, this, [=](){
        QMessageBox addBox;
        addBox.setStandardButtons(QMessageBox::Save | QMessageBox::Discard | QMessageBox::Cancel);
        addBox.setIcon(QMessageBox::Information);
        addBox.setWindowTitle("读取");
        addBox.setText("请选择读取内容");
        addBox.button(QMessageBox::Save)->setText("读取数据");
        addBox.button(QMessageBox::Discard)->setText("读取exc");
        addBox.button(QMessageBox::Cancel)->setText("取消读取");
        addBox.setDefaultButton(QMessageBox::Cancel);
        int ret = addBox.exec();
        if(ret == QMessageBox::Save) {
            QMessageBox dddBox;
            dddBox.setStandardButtons(QMessageBox::Save | QMessageBox::Discard | QMessageBox::Cancel);
            dddBox.setIcon(QMessageBox::Information);
            dddBox.setWindowTitle("选择文件");
            dddBox.setText("请选择读取文件");
            dddBox.button(QMessageBox::Save)->setText("默认数据库");
            dddBox.button(QMessageBox::Discard)->setText("其他数据库");
            dddBox.button(QMessageBox::Cancel)->setText("取消读取");
            dddBox.setDefaultButton(QMessageBox::Cancel);
            int rret = dddBox.exec();
            if(rret == QMessageBox::Save) {
                flag = false;
                emit this->init();
            } else if (rret == QMessageBox::Discard) {
                emit this->read_new();
                flag = false;
            }
        } else if (ret == QMessageBox::Discard) {
            QString read_path = QFileDialog::getOpenFileName(this, "读取数据库文件", "", "files(*.csv)");
            if(read_path.isEmpty()) {
                QMessageBox::information(this,"提示", "已取消读取");
                return;
            }
            QString save_dir = QFileInfo(read_path).path();
            save_dir.append("/");
            QString save_name = QFileInfo(read_path).fileName();
            std::string save_txt = Student_Manager::ToString(save_dir+save_name);
            save_txt[save_txt.length() - 1] = 't';
            save_txt[save_txt.length() - 2] = 'x';
            save_txt[save_txt.length() - 3] = 't';
            std::ifstream ifs(save_txt, std::ios::in);
            if(!ifs.is_open()) {
                QMessageBox::critical(this,"警告","文件损坏，读取失败！");
                return;
            }
            flag = false;
            Student_Manager::Clear_All_List();
            Student_Manager::PSTU.clear(), Student_Manager::MSTU.clear(), Student_Manager::CSTU.clear(), Student_Manager::ID.clear(), Student_Manager::name_num.clear(), Student_Manager::num_stu.clear(), Student_Manager::unm_id.clear();
            QAxObject *excel = new QAxObject("Excel.Application");
            QAxObject * workbooks;
            QAxObject * workbook;
            QAxObject * worksheets;
            QAxObject * worksheet;
            QAxObject * usedrange_Read;//读取数据矩形区域
            QAxObject * rows;//行数
            QAxObject * columns;//列数
            int WorkSheetCount;//Excel文件中表的个数
            int RowsCount;//行总数
            int ColumnsCount;//列总数
            int StartRow;//数据的起始行
            int StartColumn;//数据的起始列
            excel = new QAxObject("Excel.Application");//加载Excel驱动
            excel->setProperty("Visible", false); //不显示Excel界面，如果为true会看到启动的Excel界面
            workbooks = excel->querySubObject("WorkBooks");
            workbooks->dynamicCall("Open(const QString&)", read_path);//按文件路径打开已存在的工作簿
            workbook = excel->querySubObject("ActiveWorkBook");// 获取活动工作簿
            worksheets = workbook->querySubObject("WorkSheets");// 获取打开的excel文件中所有的工作sheet
            WorkSheetCount = worksheets->property("Count").toInt();//Excel文件中表的个数:
            worksheet = worksheets->querySubObject("Item(int)", 1);//获取第一个工作表，最后参数填1
            usedrange_Read = worksheet->querySubObject("UsedRange");//获取该sheet的数据范围
            //获取行数
            rows = usedrange_Read->querySubObject("Rows");
            RowsCount = rows->property("Count").toInt();
            //获取列数
            columns = usedrange_Read->querySubObject("Columns");
            ColumnsCount = columns->property("Count").toInt();
            //数据的起始行
            StartRow = rows->property("Row").toInt();
            //数据的起始列
            StartColumn = columns->property("Column").toInt();
            std::string student_id, name, classname, Username;//定义需要输入的内容
            int grade, sex, age, professional, english, program_design, advance_mathematics, chinese, math, English, geographic, history;
            std::vector<std::pair<int,std::pair<std::string,std::pair<std::string,std::pair<int,std::pair<int,std::pair<std::string,std::string>>>>>>> person;
            while(ifs >> grade >> student_id >> name >> sex >> age >> classname >> Username) {
                person.push_back({grade,{student_id,{name,{sex,{age,{classname,Username}}}}}});
            }
            if (worksheet != NULL && !worksheet->isNull())
            {
                if (NULL == usedrange_Read || usedrange_Read->isNull())
                {
                    QMessageBox::critical(this, "警告", "该文件不存在!");
                    return;
                }
                std::vector<int> vt(7);
                for(int i = 1; i < RowsCount; ++i) {
                    vt.clear();
                    for(int j = 4; j < 11; ++j) {
                        QAxObject* cell = worksheet->querySubObject("Cells(int, int)",StartRow + i, StartColumn + j);//获取单元格
                        vt[j-4] = cell->dynamicCall("Value2()").toString().toInt();
                    }
                    /*for(int j = 0 ;j < 7; ++j) {
                        qDebug() <<vt[j];
                    }*/
                    grade = person[i - 1].first;
                    student_id = person[i - 1].second.first;
                    name = person[i - 1].second.second.first;
                    sex = person[i - 1].second.second.second.first;
                    age = person[i - 1].second.second.second.second.first;
                    classname = person[i - 1].second.second.second.second.second.first;
                    Username = person[i - 1].second.second.second.second.second.second;
                    if(grade == 2) {
                        chinese = vt[0];
                        math = vt[1];
                        English = vt[2];
                        Primary_student* pstu=new Primary_student(student_id, name, sex, age, classname, 2, Username, English, math, chinese);
                        Student_Manager::PSTU.push_back(pstu);//小学生链表增加
                        Student_Manager::name_num.insert({ name , student_id });//关联学号和姓名
                        Student_Manager::num_stu.insert({ student_id,pstu });//关联学号和学生基本信息
                    } else if(grade == 3) {
                        chinese = vt[0];
                        math = vt[1];
                        English = vt[2];
                        geographic = vt[3];
                        history = vt[4];
                        Middle_student* mstu = new Middle_student(student_id, name, sex, age, classname, 3, Username, English, math, chinese, geographic, history);
                        Student_Manager::MSTU.push_back(mstu);//中学生链表增加
                        Student_Manager::name_num.insert({ name , student_id });//关联学号和姓名
                        Student_Manager::num_stu.insert({ student_id,mstu });//关联学号和学生基本信息
                    } else{
                        professional = vt[5];
                        english = vt[2];
                        program_design = vt[6];
                        advance_mathematics = vt[7];
                        College_student* cstu = new College_student(student_id, name, sex, age, classname, 4, Username, professional, english, program_design, advance_mathematics);
                        Student_Manager::CSTU.push_back(cstu);//学生链表增加
                        Student_Manager::name_num.insert({ name , student_id });//关联学号和姓名
                        Student_Manager::num_stu.insert({ student_id,cstu });//关联学号和学生基本信息
                    }
                }
            }
            ifs.close();
            std::string id(save_txt, 0, save_txt.length() - 4);
            id.append("id.txt");
            std::ifstream ifs_user(id, std::ios::in);
            int Id;
            std::string username,password;
            while (ifs_user >> Id && ifs_user >> username && ifs_user >> password) {
                Student_Manager::ID.push_back(new Account(username, password, Id));//添加用户
                Student_Manager::unm_id.insert({ username,Id });//关联用户和身份
            }
            workbook->dynamicCall("Close(bool)", false);  //关闭文件
            excel->dynamicCall("Quit()");
        }
    });

    //监听返回
    connect(sc, &sort_and_check::choice_return, this, [=](){
        sc->close();
        this->show();
        this->setGeometry(sc->geometry());//设置位置保持一致
    });

    connect(ap, &Add_Person::choice_return, this, [=](){
        //更新表单
        sc->init();
        ap->close();
        this->show();
        this->setGeometry(ap->geometry());//设置位置保持一致
        flag = false;
    });

    connect(fp, &Find_Person::choice_return, this, [=](){
        fp->close();
        this->show();
        this->setGeometry(fp->geometry());//设置位置保持一致
    });

    connect(dp, &Delete_Person::choice_return, this, [=](){
        //更新表单
        sc->init();
        dp->close();
        this->show();
        this->setGeometry(dp->geometry());//设置位置保持一致
        flag = false;
    });

    connect(cp, &Change_Person::choice_return, this, [=](){
        //更新表单
        sc->init();
        cp->close();
        this->show();
        this->setGeometry(cp->geometry());//设置位置保持一致
        flag = false;
    });

}

Menu::~Menu() {
    delete ui;
}

void Menu::paintEvent(QPaintEvent *){
    QPainter painter(this);
    QPixmap pix;
    pix.load(":/image/School.png");
    pix = pix.scaled(pix.width() * 0.35, pix.height() * 0.35);
    painter.drawPixmap(0, 10, pix);
}
