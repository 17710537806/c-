#ifndef STUDENT_MANAGER_H
#define STUDENT_MANAGER_H
#include<QMainWindow>
#include<QPaintEvent>
#include<QPainter>
#include<fstream>
#include<list>
#include<unordered_map>
#include<string>
#include<set>
#include<account.h>
#include<student.h>
#include<primary_student.h>
#include<middle_student.h>
#include<college_student.h>
#include<GlobalFile.h>
#include<student_menu.h>
QT_BEGIN_NAMESPACE
namespace Ui {
    class Student_Manager;
}
QT_END_NAMESPACE
struct STU_NAME {//mutiset内成员
    std::string student_name, student_identity;
    friend bool operator < (STU_NAME x, STU_NAME y) {//用友元保证可以重载
        return x.student_name < y.student_name&& x.student_name == y.student_name && x.student_identity < y.student_identity;
    }
};
class Student_Manager : public QMainWindow{
    Q_OBJECT
public:
    friend class sort_and_check;
    friend class Add_Person;
    friend class Add_Manager;
    friend class Find_Person;
    friend class Find_Manager;
    friend class Delete_Person;
    friend class Delete_Manager;
    friend class Change_Person;
    friend class Change_Manager;
    friend class Menu;
    friend class Change_psw;

    void init(bool flag = true);//初始化链表，读入数据

    void save();

    void save_id_list();

    bool check(int id, std::string username, std::string password);//检查登录是否合法

    static std::string ToString(const QString qStr);//解决Qstring转string乱码问题

    Student_Manager(QWidget *parent = nullptr);

    static void remove(std::list<Account*>&ID, std::string name);

    ~Student_Manager();
private:
    Ui::Student_Manager *ui;
    static std::list<Account*>ID;//用户链表
    static std::unordered_map<std::string, int>unm_id;//关联用户名和用户身份
    static std::list<Primary_student*>PSTU;//小学生链表
    static std::list<Middle_student*>MSTU;//中学生链表
    static std::list<College_student*>CSTU;//大学生链表
    static std::multiset<STU_NAME>name_num;//关联学生名字和学生学号,使用multiset而不是map或者set原因在于允许成员重复,并且可以将姓名排序，内部为红黑树
    static std::unordered_map<std::string, Student*>num_stu;//关联学生学号和学生所有信息，使用哈希表而不是用map红黑树的原因是哈希表插入和查找更快，为O(1),红黑树为O(logn)但稳定

    static std::string Username;
    static std::string Password;
    template<typename Type>
    static bool Compare_id(Type& A1, Type& A2);//比较函数，函数模板排序账户的身份
    template<typename Type>
    static bool Compare_Username(Type& A1, Type& A2);//比较函数，函数模板排序账户的用户名
    template<typename Type>
    static bool Compare_Ad_math(Type& A1, Type& A2);//比较函数，函数模板排序学生成绩链表的高等数学成绩
    template<typename Type>
    static bool Compare_Chinese(Type& A1, Type& A2);//比较函数，函数模板排序学生成绩链表的语文成绩
    template<typename Type>
    static bool Compare_Math(Type& A1, Type& A2);//比较函数，函数模板排序学生成绩链表的数学成绩
    template<typename Type>
    static bool Compare_English(Type& A1, Type& A2);//比较函数，函数模板排序学生成绩链表的英语成绩
    template<typename Type>
    static bool Compare_Geographic(Type& A1, Type& A2);//比较函数，函数模板排序学生成绩链表的地理成绩
    template<typename Type>
    static bool Compare_History(Type& A1, Type& A2);//比较函数，函数模板排序学生成绩链表的历史成绩
    template<typename Type>
    static bool Compare_Professional(Type& A1, Type& A2);//比较函数，函数模板排序学生成绩链表的专业成绩
    template<typename Type>
    static bool Compare_Program_design(Type& A1, Type& A2);//比较函数，函数模板排序学生成绩链表的程序设计成绩
    template<typename Type>
    static bool Compare_Student_id(Type& A1, Type& A2);//比较函数，函数模板排序学生成绩链表的学号成绩
    template<typename Type>
    static bool Compare_pri_sum(Type& A1, Type& A2);//比较函数，函数模板排序学生成绩链表的语数英成绩
    template<typename Type>
    static bool Compare_all_sum(Type& A1, Type& A2);//比较函数，函数模板排序学生成绩链表的所有科成绩（高中,大学）
    template<typename Type>
    static bool Compare_mid_sum(Type& A1, Type& A2);//比较函数，函数模板排序学生成绩链表的历史地理总分成绩
    template<typename Type>
    static bool Compare_class(Type& A1, Type& A2);//比较函数，函数模板排序学生成绩链表的班级

    template<typename Type>
    static void List_Sort(std::list<Type>& List, bool(*compare)(Type& A1, Type& A2));//用函数模板接收不同类型的链表，并用函数指针调用不同的比较函数进行排序
    static void Sort_Function(int result);

    //清空指针的万能函数
    template<typename Type>
    static void Clear_list(std::list<Type>& lt);

    static void Clear_All_List();

    //画背景图
    void paintEvent(QPaintEvent *);
};
#endif // STUDENT_MANAGER_H
